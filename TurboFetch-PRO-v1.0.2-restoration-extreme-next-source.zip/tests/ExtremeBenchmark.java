import com.turbofetch.core.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
/** One controlled trial. Compiled separately against unchanged Ultimate and Extreme source trees. */
public final class ExtremeBenchmark {
 static long metric(Job j,String field){try{return ((java.util.concurrent.atomic.AtomicLong)Job.class.getField(field).get(j)).get();}catch(Exception e){return -1;}}
 public static void main(String[] args)throws Exception{
  String label=args[0],scenario=args[1];int trial=Integer.parseInt(args[2]);int mib=scenario.equals("delayed")?64:128;
  File root=Files.createTempDirectory("turbo-paired-").toFile();
  try(EngineIntegration.Server s=new EngineIntegration.Server(mib*1048576){
   @Override void serve(com.sun.net.httpserver.HttpExchange x)throws IOException{if(scenario.equals("request-latency"))try{Thread.sleep(180);}catch(InterruptedException e){Thread.currentThread().interrupt();x.close();return;}super.serve(x);}
  }){
   s.slow=scenario.equals("delayed");s.delayMillis=4;String hash=EngineIntegration.hash(s.data);
   Store st=new Store(new File(root,"jobs"));Job j=st.add(s.url(),"file.bin",32,hash,"");Engine.Control c=new Engine.Control();c.dynamicRanges=true;c.directStorage=true;c.network="Wi-Fi";File output=new File(root,"out.bin");if(label.equals("Pipeline"))Engine.Control.class.getField("pipelineMode").setInt(c,1);
   long start=System.nanoTime();new Engine().run(j,c,EngineIntegration.publisher(output));double secs=(System.nanoTime()-start)/1e9;
   EngineIntegration.require(j.state==Job.State.COMPLETED&&Arrays.equals(EngineIntegration.read(output),s.data),"benchmark integrity "+j.error);
   System.out.printf(Locale.US,"RESULT,%s,%s,%d,%.4f,%.4f,%d,%d,%d,%d,SHA256_OK%n",label,scenario,trial,secs,mib/secs,s.requests.size(),j.partCount,metric(j,"dataSyncs"),metric(j,"checkpointWrites"));
  }finally{try(var w=Files.walk(root.toPath())){w.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(IOException ignored){}});}}
 }
}
