import com.turbofetch.core.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
public final class ExtremeIntegration {
 static final long M=1048576L;
 static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);}
 static void pass(String s){System.out.println("PASS EXTREME "+s);}
 static Engine.Control auto(boolean extreme){Engine.Control c=new Engine.Control();c.directStorage=true;c.dynamicRanges=true;c.extreme=extreme;return c;}
 public static void main(String[] args)throws Exception{
  check(ExtremePolicy.segmentSize(8*1024*M,32,8)>8*M,"large geometry");check(ExtremePolicy.segmentSize(256*1024*M,32,8)<=256*M,"bounded geometry");check(ExtremePolicy.segmentSize(8*M,32,8)==M,"small geometry");pass("adaptive segment sizing with bounded large-file geometry");
  check(ExtremePolicy.checkpointBytes(0)==8*M&&ExtremePolicy.checkpointBytes(40*M)==32*M,"dirty bound");check(ExtremePolicy.readTimeout("Cellular")>ExtremePolicy.readTimeout("Wi-Fi"),"timeout policy");pass("bounded checkpoint and network timeout policy");
  File root=Files.createTempDirectory("turbo-extreme-test").toFile(),out=new File(root,"out.bin");
  try(EngineIntegration.Server server=new EngineIntegration.Server(48*(int)M)){
   Store st=new Store(new File(root,"jobs"));Job j=st.add(server.url(),"file.bin",8,EngineIntegration.hash(server.data),"");Engine.Control control=auto(true);final Job first=j;Thread worker=new Thread(()->new Engine().run(first,control,EngineIntegration.publisher(out)));worker.start();long deadline=System.nanoTime()+15_000_000_000L;while(j.bytes.get()<5*M&&worker.isAlive()&&System.nanoTime()<deadline)Thread.sleep(5);control.pause();worker.join(20000);check(!worker.isAlive()&&j.state==Job.State.PAUSED&&j.journal&&j.direct,"pause: "+j.error);
   long saved=j.bytes.get();check(saved>0&&saved<j.total,"partial bytes");File journal=new File(j.dir,"part-journal.bin");check(journal.isFile()&&j.dataSyncs.get()>0,"journal missing");for(int n=0;n<j.partCount;n++)check(!j.checkpoint(n).exists(),"unexpected old checkpoint");pass("new direct jobs use shared synced checkpoint journal");
   // An interrupted atomic replacement leaves the authoritative journal unchanged.
   Files.write(new File(j.dir,"part-journal.bin.tmp").toPath(),new byte[]{1,2,3});String id=j.id;st=new Store(new File(root,"jobs"));j=st.get(id);check(j!=null&&j.bytes.get()==saved,"interrupted checkpoint recovery");pass("interrupted journal replacement keeps committed bytes");
   byte[] raw=Files.readAllBytes(journal.toPath());byte[] bad=raw.clone();bad[bad.length-1]^=1;Files.write(journal.toPath(),bad);Store corrupt=new Store(new File(root,"jobs"));check(corrupt.get(id)==null&&j.directFile().exists(),"corrupt journal not rejected safely");Files.write(journal.toPath(),raw);st=new Store(new File(root,"jobs"));j=st.get(id);check(j!=null&&j.bytes.get()==saved,"restored journal");pass("corrupt journal fails closed without deleting payload");
   List<long[]> committed=new ArrayList<>();for(int n=0;n<j.partCount;n++){long p=j.recover(n);if(p>0)committed.add(new long[]{j.start(n),j.start(n)+p-1});}server.requests.clear();server.slow=false;new Engine().run(j,auto(true),EngineIntegration.publisher(out));check(j.state==Job.State.COMPLETED&&Arrays.equals(EngineIntegration.read(out),server.data),"journal resume "+j.error);for(long[] r:server.requests){if(r[0]==0&&r[1]==0)continue;for(long[] p:committed)check(r[0]>p[1]||r[1]<p[0],"committed range repeated");}pass("journal pause/reopen/resume, exact SHA-256 and no repeated committed ranges");
   // A new version must not convert an existing direct job with old checkpoints.
   server.slow=true;Job old=st.add(server.url(),"old.bin",4,EngineIntegration.hash(server.data),"");Engine.Control legacy=auto(false);Thread t=new Thread(()->new Engine().run(old,legacy,EngineIntegration.publisher(out)));t.start();deadline=System.nanoTime()+15_000_000_000L;while(old.bytes.get()<3*M&&t.isAlive()&&System.nanoTime()<deadline)Thread.sleep(5);legacy.pause();t.join(20000);check(old.state==Job.State.PAUSED&&!old.journal&&old.direct,"old pause");st=new Store(new File(root,"jobs"));Job reopened=st.get(old.id);server.slow=false;new Engine().run(reopened,auto(true),EngineIntegration.publisher(out));check(reopened.state==Job.State.COMPLETED&&!reopened.journal&&Arrays.equals(EngineIntegration.read(out),server.data),"legacy journal compatibility");pass("old direct checkpoint backend retained through upgrade");
  }finally{try(var w=Files.walk(root.toPath())){w.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(IOException ignored){}});}}
  System.out.println("EXTREME TOTAL PASSED: 7");
 }
}
