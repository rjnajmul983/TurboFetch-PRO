import com.turbofetch.core.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;

/** Optional 5 GiB localhost integration test, generated data, no external downloads. */
public final class LargeResume {
    static final long GIB=1024L*1024*1024, TOTAL=5*GIB;
    static final int BLOCK=65536;
    static final byte[] BASE=new byte[BLOCK];static {new Random(932).nextBytes(BASE);}
    static void fill(byte[] b,long block){System.arraycopy(BASE,0,b,0,BLOCK);for(int i=0;i<8;i++)b[i]=(byte)(block>>>(i*8));}
    static void require(boolean b,String message){if(!b)throw new AssertionError(message);}
    public static void main(String[] args)throws Exception{
        File root=Files.createTempDirectory("turbo-large-").toFile();
        require(root.getUsableSpace()>11*GIB,"Large test needs at least 11 GiB free storage");
        ExecutorService executor=Executors.newCachedThreadPool();HttpServer http=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);http.setExecutor(executor);
        List<long[]> requests=Collections.synchronizedList(new ArrayList<>());
        http.createContext("/large",x->{long start=0,end=TOTAL-1;String r=x.getRequestHeaders().getFirst("Range");int status=200;
            if(r!=null){String[] p=r.substring(6).split("-",-1);start=Long.parseLong(p[0]);end=p[1].isEmpty()?end:Math.min(end,Long.parseLong(p[1]));status=206;x.getResponseHeaders().set("Content-Range","bytes "+start+"-"+end+"/"+TOTAL);requests.add(new long[]{start,end});}
            x.getResponseHeaders().set("ETag","\"large-generated-v1\"");x.sendResponseHeaders(status,end-start+1);
            try(OutputStream out=x.getResponseBody()){byte[] b=new byte[BLOCK];long pos=start;while(pos<=end){fill(b,pos/BLOCK);int off=(int)(pos%BLOCK);int n=(int)Math.min(BLOCK-off,end-pos+1);out.write(b,off,n);pos+=n;}}catch(IOException ignored){}finally{x.close();}
        });http.start();
        try{
            System.out.println("Computing expected SHA-256 of generated 5 GiB resource");MessageDigest digest=MessageDigest.getInstance("SHA-256");byte[] b=new byte[BLOCK];for(long pos=0;pos<TOTAL;pos+=BLOCK){fill(b,pos/BLOCK);digest.update(b);}String expected=HexFormat.of().formatHex(digest.digest());
            Store store=new Store(new File(root,"jobs"));Job j=store.add("http://127.0.0.1:"+http.getAddress().getPort()+"/large","large.bin",8,expected,"");String id=j.id;File out=new File(root,"out.bin");Engine.Publisher publisher=(job,c)->{try(FileOutputStream o=new FileOutputStream(out)){Engine.copyParts(job,o,c);o.getFD().sync();}return out.toString();};
            boolean direct=args.length>0&&(args[0].equals("direct")||args[0].equals("pipeline"));boolean pipeline=args.length>0&&args[0].equals("pipeline");Engine.Control control=new Engine.Control();control.directStorage=direct;control.dynamicRanges=direct;control.pipelineMode=pipeline?1:0;final Job first=j;Thread t=new Thread(()->new Engine().run(first,control,publisher));long start=System.nanoTime();t.start();while(t.isAlive()&&j.bytes.get()<2*GIB)Thread.sleep(20);control.pause();t.join();require(j.state==Job.State.PAUSED,"Failed to pause: "+j.state+" "+j.error);long saved=j.bytes.get();require(saved>=2*GIB&&saved<TOTAL,"Expected about 2 GiB saved");System.out.println("Paused with "+saved+" durable bytes");
            store=new Store(new File(root,"jobs"));j=store.get(id);require(j.bytes.get()==saved,"Checkpoint bytes differ after reopen");List<long[]> committed=new ArrayList<>();for(int n=0;n<j.partCount;n++){long at=j.recover(n);if(at>0)committed.add(new long[]{j.start(n),j.start(n)+at-1});}requests.clear();
            Engine.Control resume=new Engine.Control();resume.directStorage=direct;resume.dynamicRanges=direct;resume.pipelineMode=pipeline?1:0;if(direct){j.connections=32;j.save();}new Engine().run(j,resume,publisher);require(j.state==Job.State.COMPLETED,"Resume failed: "+j.error);require(out.length()==TOTAL,"Incorrect output length");for(long[] r:requests){if(r[0]==0&&r[1]==0)continue;for(long[] p:committed)require(r[0]>p[1]||r[1]<p[0],"Committed range requested twice");}
            MessageDigest actual=MessageDigest.getInstance("SHA-256");try(InputStream in=new BufferedInputStream(new FileInputStream(out),1024*1024)){byte[] chunk=new byte[1024*1024];int n;while((n=in.read(chunk))!=-1)actual.update(chunk,0,n);}
            require(expected.equals(HexFormat.of().formatHex(actual.digest())),"Output SHA-256 mismatch");if(pipeline)require(j.pipelineWrites.get()>0,"Pipeline did not execute");System.out.println("Storage mode: "+(direct?"direct private file + dynamic ranges":"legacy segmented"));System.out.printf(Locale.US,"PASS 5 GiB (%,d bytes), paused after %,d bytes, no committed range re-requested, final file SHA-256 %s, elapsed %.1fs%n",TOTAL,saved,expected,(System.nanoTime()-start)/1e9);
        }finally{http.stop(0);executor.shutdownNow();try(java.util.stream.Stream<Path> walk=Files.walk(root.toPath())){walk.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(IOException ignored){}});}}
    }
}
