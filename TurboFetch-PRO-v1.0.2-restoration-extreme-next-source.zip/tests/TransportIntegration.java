import com.turbofetch.core.*;
import java.io.*;import java.net.*;import java.nio.file.*;import java.util.*;import java.util.concurrent.atomic.*;
public final class TransportIntegration {
 public static void main(String[] args)throws Exception{
  File root=Files.createTempDirectory("transport-test").toFile();try(EngineIntegration.Server s=new EngineIntegration.Server(8*1024*1024)){
   s.slow=false;Store st=new Store(root);Job j=st.add(s.url(),"file",8,EngineIntegration.hash(s.data),"");Engine.Control c=new Engine.Control();AtomicInteger open=new AtomicInteger(),verified=new AtomicInteger(),fallback=new AtomicInteger();
   c.transport=new Engine.Transport(){public HttpURLConnection open(URL u,boolean safe)throws IOException{if(safe)verified.incrementAndGet();if(open.getAndIncrement()==0)return new HttpURLConnection(u){public void connect(){}public void disconnect(){}public boolean usingProxy(){return false;}public int getResponseCode()throws IOException{throw new IOException("simulated accelerated transport failure");}};return (HttpURLConnection)u.openConnection();}public void failed(HttpURLConnection c,IOException e){fallback.incrementAndGet();}};
   File out=new File(root,"out");new Engine().run(j,c,EngineIntegration.publisher(out));EngineIntegration.require(j.state==Job.State.COMPLETED&&Arrays.equals(s.data,EngineIntegration.read(out)),j.error);EngineIntegration.require(fallback.get()==1&&verified.get()>0,"transport hook/fallback not exercised");System.out.println("PASS transport failure recovery, verified-range routing and SHA-256");
   Job noHash=st.add(s.url(),"nohash",4,"","");AtomicInteger forbidden=new AtomicInteger();Engine.Control d=new Engine.Control();d.transport=(url,safe)->{if(safe)forbidden.incrementAndGet();return (HttpURLConnection)url.openConnection();};new Engine().run(noHash,d,EngineIntegration.publisher(out));EngineIntegration.require(noHash.state==Job.State.COMPLETED&&forbidden.get()==0,"unverified route eligibility");System.out.println("PASS dual-route eligibility requires trusted expected checksum and strong validator");
  }finally{try(var w=Files.walk(root.toPath())){w.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(IOException ignored){}});}}
 }
}
