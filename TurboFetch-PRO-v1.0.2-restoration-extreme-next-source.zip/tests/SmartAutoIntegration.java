import com.turbofetch.core.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.*;
import com.sun.net.httpserver.*;
import java.net.*;
import java.util.concurrent.*;

public final class SmartAutoIntegration {
    static int passed;
    static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    static void pass(String s){System.out.println("PASS SMART "+s);passed++;}
    static int converge(AutoTuner t,int cap,java.util.function.IntToDoubleFunction rate){int peak=0;for(int i=0;i<150;i++){int count=t.desired();peak=Math.max(peak,count);t.observe(rate.applyAsDouble(count),count,cap,false);}return peak;}
    static void mainTests(File root)throws Exception{
        AutoTuner t=new AutoTuner(32,0);int peak=converge(t,32,n->n<=16?n*1000:16000-(n-16)*250);
        check(peak>8&&t.best()==16,"failed to discover best workers: peak="+peak+" best="+t.best());pass("automatic exploration above 8 and selection of measured best 16 workers");
        AutoTuner flat=new AutoTuner(32,24);converge(flat,32,n->10000);check(flat.best()==1,"flat server should choose one, got "+flat.best());pass("flat throughput reduces worker count to one");
        flat.observe(1000,flat.desired(),1,false);check(flat.desired()==1,"thermal cap");check(flat.bufferBytes(1000,1)==65536&&flat.bufferBytes(64L*1024*1024,1)==524288,"buffer scaling");pass("worker cap and bounded adaptive buffers");
        AutoTuner shortJob=new AutoTuner(32,0);for(int i=0;i<30;i++)shortJob.observe(1000,4,32,true);check(shortJob.desired()==4,"short job unnecessarily tuned");pass("near-completion avoids probing");
        ServerProfiles profiles=new ServerProfiles(root);String url="https://example.org/a?token=private";profiles.save(url,"wifi",16,10000,3);check(profiles.load("https://example.org/b?token=other","wifi")==16,"profile missing");check(profiles.load(url,"cellular")==0,"profile crosses network types");
        File[] records=new File(root,".profiles").listFiles();check(records!=null&&records.length==1,"profile count");String raw=Files.readString(records[0].toPath());check(!raw.contains("private")&&!raw.contains("example.org"),"private URL stored");Properties p=new Properties();try(InputStream in=new FileInputStream(records[0])){p.load(in);}p.setProperty("time","1");try(OutputStream out=new FileOutputStream(records[0])){p.store(out,null);}check(profiles.load(url,"wifi")==0,"stale profile accepted");profiles.clear();pass("persistent per-network profiles, privacy, expiry and reset");
        try(EngineIntegration.Server s=new EngineIntegration.Server(24*1024*1024)){
            File jobs=new File(root,"jobs"),out=new File(root,"file.bin");Store st=new Store(jobs);Job j=st.add(s.url(),"old.bin",8,EngineIntegration.hash(s.data),"");long saved=EngineIntegration.pause(j,out);String id=j.id;
            // Recreate alpha.1 metadata schema: no new fields. Existing part files and checkpoints untouched.
            File props=new File(j.dir,"job.properties");Properties old=new Properties();try(InputStream in=new FileInputStream(props)){old.load(in);}old.remove("recoverAutomatically");try(OutputStream o=new FileOutputStream(props)){old.store(o,null);}
            st=new Store(jobs);j=st.get(id);check(j.bytes.get()==saved&&j.state==Job.State.PAUSED,"legacy bytes/state lost");long[] prior=new long[j.partCount];for(int n=0;n<prior.length;n++)prior[n]=j.recover(n);j.connections=32;j.save();s.requests.clear();s.slow=false;new Engine().run(j,new Engine.Control(),EngineIntegration.publisher(out));check(j.state==Job.State.COMPLETED&&Arrays.equals(Files.readAllBytes(out.toPath()),s.data),"legacy resume "+j.error);for(long[] r:s.requests){if(r[0]==0&&r[1]==0)continue;int n=(int)(r[0]/j.blockSize);check(r[0]>=j.start(n)+prior[n],"legacy bytes requested again");}pass("alpha.1 metadata compatibility and resume after cap changes 8 to 32");
            Job recover=st.add(s.url(),"recover.bin",32,"","");recover.recoverAutomatically=true;recover.state=Job.State.RUNNING;recover.save();Job manual=st.add(s.url(),"manual.bin",32,"","");manual.state=Job.State.PAUSING;manual.save();Store reopen=new Store(jobs);check(reopen.get(recover.id).state==Job.State.WAITING_NETWORK&&reopen.get(manual.id).state==Job.State.PAUSED,"manual and automatic recovery conflated");pass("persistent recovery intent distinguishes manual pause and interruption");
            Job complete=reopen.get(id);complete.completedAt=1;complete.save();check(reopen.clearCompletedBefore(2)==1&&out.exists()&&reopen.get(manual.id)!=null,"retention deleted wrong data");pass("age-based completed history cleanup protects paused jobs and output");
        }
    }
    public static void main(String[] args)throws Exception{File root=Files.createTempDirectory("smart-auto-").toFile();try{mainTests(root);System.out.println("SMART TOTAL PASSED: "+passed);}finally{try(java.util.stream.Stream<Path> walk=Files.walk(root.toPath())){walk.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(IOException ignored){}});}}}
}
