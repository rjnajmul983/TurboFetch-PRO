import com.turbofetch.core.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
public final class EngineBenchmark {
    public static void main(String[] args)throws Exception{
        File root=Files.createTempDirectory("turbo-bench-").toFile();
        try(EngineIntegration.Server s=new EngineIntegration.Server(24*1024*1024)){
            double[] median=new double[2];int[] caps={1,8};
            for(int k=0;k<caps.length;k++){double[] times=new double[3];for(int run=0;run<3;run++){
                Store store=new Store(new File(root,"jobs-"+k+"-"+run));Job j=store.add(s.url(),"benchmark.bin",caps[k],"","");File out=new File(root,"bench.bin");long start=System.nanoTime();new Engine().run(j,new Engine.Control(),EngineIntegration.publisher(out));times[run]=(System.nanoTime()-start)/1e9;EngineIntegration.require(j.state==Job.State.COMPLETED&&Arrays.equals(Files.readAllBytes(out.toPath()),s.data),"Benchmark integrity error");}
                Arrays.sort(times);median[k]=times[1];System.out.printf(Locale.US,"Cap %d: median %.3fs, %.2f MiB/s (24 MiB, 3 runs, includes final publication)%n",caps[k],median[k],24/median[k]);}
            System.out.printf(Locale.US,"Controlled localhost median speed ratio %.2fx (NOT ISP speed or old APK comparison)%n",median[0]/median[1]);
        }finally{try(java.util.stream.Stream<Path> walk=Files.walk(root.toPath())){walk.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(IOException ignored){}});}}
    }
}
