# ফোন দিয়ে GitHub APK Build

১. আগের Private GitHub repository-তে `TurboFetch-PRO-v1.0.2-restoration-extreme-next-source.zip` আপলোড করুন। ZIP খুলবেন না।
২. আগের `TurboFetch-original.part02` একই নামে repository root-এ রাখুন। আগে আপলোড থাকলে নতুন করে লাগবে না।
৩. `.github/workflows/android-build.yml` ফাইলে নতুন `android-build-restoration-extreme-next.yml`-এর সব কোড পেস্ট করে commit করুন।
৪. Actions → TurboFetch PRO - Restoration Extreme Next → Run workflow। Branch main। স্বয়ংক্রিয় push build চললে তার সঙ্গে একযোগে দ্বিতীয় build শুরু করার প্রয়োজন নেই।
৫. 5 GiB পরীক্ষা করতে large_test, emulator পরীক্ষা করতে device_smoke, Android 16-এর জন্য device_api 36, পরীক্ষামূলক Browser UI পরীক্ষার জন্য device_browser এবং সোর্স উদ্ধারের জন্য recover_java নির্বাচন করুন। সব ঐচ্ছিক; 5 GiB পরীক্ষা runner storage ব্যবহার করে।
৬. সফল হলে Artifacts → TurboFetch-PRO-Restoration-APK থেকে ZIP ডাউনলোড/Extract করুন। APK-এর নাম `TurboFetch-PRO-v1.0.2-restoration-extreme-next-preview.apk`। test logs ও recovered source আলাদাভাবে রাখুন।
৭. পুরোনো APK-এর signing certificate আলাদা হলে সরাসরি install/update হবে না। আগের অসম্পূর্ণ ডাউনলোডের জন্য পুরোনো অ্যাপ আনইনস্টল করবেন না। মালিকের স্থায়ী key থাকলে secrets TURBO_KEYSTORE_B64, TURBO_STORE_PASSWORD, TURBO_KEY_ALIAS, TURBO_KEY_PASSWORD ব্যবহার করুন। কোনো secret repository-তে plain text রাখবেন না।
৮. নতুন direct job-এ checkpoint journal ব্যবহৃত হয়। আগের সংস্করণে downgrade করলে সেটি বুঝবে না; নতুন অসম্পূর্ণ job নিয়ে downgrade করবেন না।

স্থানীয় JVM পরীক্ষায় APK build বা Android runtime প্রমাণিত হয় না। GitHub-এ build ব্যর্থ হলে প্রথম failing step-এর error log দেখুন।
