# Restoration Extreme v1.0.1 (10006) — audit and measured results

## Scope and source provenance
Base: supplied Restoration Ultimate ZIP, with the exact original APK part01 and unchanged external part02. Original reconstruction matches SHA-256 `00fa15ad6fb3b64bc89f1bcb69c7757ba3e64004e7bed742cbe803b6f6ca14fa`, byte-for-byte against the uploaded original APK. All 124 original ZIP entries are present in the reconstructed original; all four native jlibtorrent libraries are preserved in the build input. The targeted smali patch, original preservation checker and browser regression harness are byte-identical to Ultimate. A rebuilt/signed APK has NOT been produced in this environment. This is a restoration kit, not recovered original Gradle source. CI is intended to verify DEX classes/resources after assembly.

## Audit and implementation
- Ultimate used 4–8 MiB nominal chunks for large files, per-range checkpoint files, per-worker 4 MiB or 2 s sync, fixed 12 s network timeouts, and 250 ms bridge callbacks. These are source observations, not individually profiled bottleneck measurements.
- Extreme keeps the working HTTP engine and legacy checkpoint path, with a new 1–256 MiB adaptive nominal geometry for new direct HTTP jobs (metadata size bound may increase this for extremely large files). Existing geometry remains untouched. Learned workers and file size inform range size; original live splitting is retained.
- Direct jobs use a shared sync and CRC-checked atomic journal, with 8/16/32 MiB dirty thresholds selected from actual throughput and a one-second write-triggered checkpoint interval. Worker completion, pause and split require a durable barrier. Shared sync precedes journal publication. Journal offsets validated against geometry and actual length; corrupt metadata is retained and rejected. Atomic rename does not establish hardware power-loss durability; an abrupt interruption may require re-downloading uncommitted data (threshold plus in-flight writes). No claim of zero crash loss. Earlier per-part checkpoints supported; **do not downgrade new journal-backed jobs to old versions.** CRC detects journal corruption, not authenticity of payload.
- Buffer cache bounded at 4 MiB of idle buffers; active worker buffers remain <=512 KiB each. Timeouts use network category (10/15 s Wi-Fi/Ethernet, 16/25 s otherwise) rather than measured RTT; callback updates reduced to 500 ms when changing or 2 s heartbeat, cancellation poll remains 250 ms. Diagnostics show actual request and checkpoint counts. No external AI.
- Fresh install retains original adaptive mode, max 32 and one concurrent download; explicit settings, TLS, range identity checks, existing checksums, thermal limits, cookie/referer integration, protocol modules and existing transport opt-ins retained.

## Regression evidence
- Original baseline: 34 core + 6 bridge tests passed, plus patch fixture.
- Updated: 41 core + 6 bridge tests passed, plus patch text fixture. Seven additional tests: geometry, policy bounds, journal backend, interrupted journal replacement, corrupt journal retention, actual resume with no repeated committed ranges and SHA-256, old checkpoint compatibility.
- 5 GiB direct: paused at 2,160,287,869 bytes; 5,368,709,120 bytes final, no committed ranges re-requested, SHA-256 `5fe9efe001aab0eb708687a5ffe68a9702f8200ecb2fd546732b950379347206`; 20.1 s measured after expected checksum generation. Legacy segmented: paused at 2,160,590,795 bytes; same final length and SHA-256; no committed ranges re-requested; 20.3 s. Host process reopen, not Android process-kill or hardware power-loss.

## Actual paired-version benchmark
The original Ultimate core snapshot in `baseline/java` is byte-identical to the supplied ZIP. `tools/test-compare.sh` compiles it and the new Extreme core separately; identical payload, worker cap 32, automatic tuning, direct+dynamic mode, SHA-256 check and output copy for both. Three trials per version per scenario, order alternated; all 18 SHA-256 checks passed. Raw CSV in `docs/raw/ULTIMATE_VS_EXTREME.csv`; -1 means the baseline has no instrumentation for that counter, not zero. Completion time includes verification and output publication in the JVM harness. No real phone or Internet measurements.

| Scenario | Ultimate mean MiB/s | Extreme mean MiB/s | Change | Ultimate median | Extreme median | Mean Range requests U→E |
|---|---:|---:|---:|---:|---:|---:|
| 128 MiB fast localhost | 250.40 | 255.73 | +2.13% | 295.95 | 240.04 | 45.67 → 26.67 |
| 64 MiB per-chunk delay 4 ms | 14.13 | 13.95 | −1.25% | 13.97 | 14.00 | 17 → 17 |
| 128 MiB, 180 ms delay before each response | 77.79 | 75.13 | −3.42% | 80.99 | 76.59 | 37 → 29.33 |

Fast scenario mean range requests reduced 41.61%; request-latency scenario reduced 20.72%. Speed results are mixed and fast scenario highly variable. No consistent or large speed gain demonstrated; keep the new changes as a preview for lower request count and checkpoint resilience, not a stable speed upgrade. Baseline fsync counts not measured; cannot claim exact fsync savings. Run actual paired real-device tests before adopting.

## Open master-prompt requirements
- Existing AutoTuner remains; fully redesigned rapid predictive tuning, measured RTT-adaptive timeout and learned segment/buffer/protocol profiles not implemented. No proof of globally optimal speed.
- Asynchronous bounded disk pipeline and additional connection-pool/DNS implementation not completed. No forced extra connections or weakening TLS. Browser scanner unchanged; cross-protocol resource prioritization not implemented.
- Public MediaStore/SAF direct writing and zero-copy finalization remain open. Private positional writing works; final public copy may still be necessary.
- Android HttpEngine and consent-based dual-network code retained from Ultimate, not actually tested for negotiated HTTP/3, QUIC, physical dual-network routing or speed. Adaptive per-network load balancing/data budget not implemented.
- Original FTP REST deletion guard retained and host tested; Torrent/Magnet and HLS/DASH original code preserved but enhanced all-protocol resume not completed. No real protocol/device regression proof.
- Local JDK 21 compiling Java 17 host code available. Android SDK, D8, Apktool and Gradle unavailable. Attempts to access dl.google.com and github.com failed DNS. Actual Android assembly, signing, APK installation, device regression and browser scan remain unverified. Workflow YAML parsed, shell syntax checked, version patch tested on actual original AXML. CI workflow retains APK reconstruction, build, preservation check, optional emulator and scanner checks and raw log uploads.

Do not call this stable, do not uninstall original app with important pending downloads, and do not claim all master-prompt items completed. Signing requires compatible original/owner key for an in-place upgrade. GitHub build is needed before device testing.
