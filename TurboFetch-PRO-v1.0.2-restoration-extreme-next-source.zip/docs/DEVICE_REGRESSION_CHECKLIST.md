# Device release gates (not executed locally)
1. Confirm APK verifies, package com.turbofetch.app, version 1.0.0; test with compatible signature or separate test profile.
2. Open original UI and Settings; search via browser, visit a controlled page with files; auto detection, Scan Page, Scan All Links, Find Files, verify/filter, multiple tabs and selection. Test browser cookie-protected same-origin download and custom filename.
3. HTTP: fresh install default 32 cap/adaptive enabled/one file; test plain Range file, pause/resume after process reopen, 5 GiB and SHA-256, non-range rejection, changed validator preservation, limit setting and cancellation. Ensure original notification, queue and export work.
4. Legacy partial: same-signature test upgrade with a controlled saved job, verify old file not lost. Invalid legacy geometry must fail with a clear message, not restart.
5. History: completed and cancelled records removed, failed without data removed, active and resumable records preserved; completed public files retained.
6. Verify original torrent/magnet using legal test torrent, FTP with controlled server, HLS and DASH using authorized non-DRM samples. Verify selected files, download notifications, output paths, pause/cancel; original limitations may remain.
7. Test Wi-Fi/mobile restrictions, Android 16 background execution and output storage permissions. Compare identical links/servers against original before speed claims.
8. Inspect CI preservation and signing logs; no stable release until all gates pass.
