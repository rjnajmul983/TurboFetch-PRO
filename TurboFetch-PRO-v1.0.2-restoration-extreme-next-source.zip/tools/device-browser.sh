#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/logs/device
fixture=$(mktemp -d)
trap '[[ -z "${server:-}" ]] || kill "$server" 2>/dev/null || true; rm -rf "$fixture"' EXIT
printf '<html><title>TurboFetch local scanner fixture</title><a href="sample.zip">Archive</a><a href="sample.pdf">Document</a><a href="sample.mp4">Video</a></html>' > "$fixture/index.html"
for ext in zip pdf mp4; do printf 'controlled fixture, not a real media file\n' > "$fixture/sample.$ext"; done
python3 -m http.server 18765 --bind 127.0.0.1 --directory "$fixture" > build/logs/device/browser-server.txt 2>&1 & server=$!
adb reverse tcp:18765 tcp:18765
adb shell pm grant com.turbofetch.app android.permission.POST_NOTIFICATIONS || true
adb shell input keyevent KEYCODE_BACK || true
adb shell monkey -p com.turbofetch.app -c android.intent.category.LAUNCHER 1 >/dev/null
sleep 3
# UI-driving harness: fail explicitly if controls are missing rather than reporting a fake pass.
python3 tools/device-browser.py
