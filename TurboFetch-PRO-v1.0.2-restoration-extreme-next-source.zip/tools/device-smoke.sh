#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/logs/device
apk=build/output/TurboFetch-PRO-v1.0.2-restoration-extreme-next-preview.apk
adb wait-for-device
adb shell getprop ro.build.version.sdk > build/logs/device/api.txt
adb logcat -c
adb install -r "$apk" | tee build/logs/device/install.txt
adb shell pm path com.turbofetch.app | tee build/logs/device/package.txt
adb shell monkey -p com.turbofetch.app -c android.intent.category.LAUNCHER 1 | tee build/logs/device/launch.txt
sleep 6
adb shell pidof com.turbofetch.app | tee build/logs/device/pid.txt
adb shell uiautomator dump /sdcard/turbo-window.xml
adb pull /sdcard/turbo-window.xml build/logs/device/window.xml
adb exec-out screencap -p > build/logs/device/launch.png
adb logcat -d > build/logs/device/logcat.txt
python3 - <<'PY'
from pathlib import Path
import re
s=Path('build/logs/device/logcat.txt').read_text(errors='replace')
assert not re.search(r'FATAL EXCEPTION[^\n]*\n[^\n]*Process: com\.turbofetch\.app(?:,|:)',s), 'TurboFetch fatal exception'
assert 'com.turbofetch.app' in Path('build/logs/device/window.xml').read_text(), 'Original application UI not visible'
print('PASS installation and launcher UI smoke test; protocol/device regression not covered')
PY
