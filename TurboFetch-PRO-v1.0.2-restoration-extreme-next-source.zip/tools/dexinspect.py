import zipfile,struct,sys,re
for n in zipfile.ZipFile(sys.argv[1]).namelist():
 if not re.fullmatch(r'classes\d*\.dex',n):continue
 b=zipfile.ZipFile(sys.argv[1]).read(n);u=lambda o:struct.unpack_from('<I',b,o)[0];h=lambda o:struct.unpack_from('<H',b,o)[0]
 def leb(o):
  v=0;s=0
  while True:
   c=b[o];o+=1;v|=(c&127)<<s;s+=7
   if c<128:return v,o
 def st(i):
  o=u(u(60)+i*4);_,o=leb(o);return b[o:b.index(0,o)].decode('utf8','replace')
 strings=[st(i) for i in range(u(56))];types=[strings[u(u(68)+4*i)] for i in range(u(64))]
 protos=[]
 for i in range(u(72)):
  o=u(76)+12*i; params=u(o+8);protos.append('('+(''.join(types[h(params+4+2*k)] for k in range(u(params))) if params else '')+')'+types[u(o+4)])
 mo=u(92);methods=[types[h(mo+8*i)]+'->'+strings[u(mo+8*i+4)]+protos[h(mo+8*i+2)] for i in range(u(88))]
 fo=u(84);fields=[types[h(fo+8*i)]+'->'+strings[u(fo+8*i+4)]+':'+types[h(fo+8*i+2)] for i in range(u(80))]
 for i in range(u(96)):
  o=u(100)+32*i;name=types[u(o)];data=u(o+24)
  if not re.search(sys.argv[2],name) or not data:continue
  print('\n',n,name);a=[]
  for _ in range(4):v,data=leb(data);a.append(v)
  for count in a[:2]:
   idx=0
   for _ in range(count):
    d,data=leb(data);idx+=d;fl,data=leb(data);print('FIELD',hex(fl),fields[idx])
  for count in a[2:]:
   idx=0
   for _ in range(count):
    d,data=leb(data);idx+=d;fl,data=leb(data);code,data=leb(data);m=methods[idx];print('METHOD',hex(fl),m)
    if not code or len(sys.argv)<4 or not re.search(sys.argv[3],m):continue
    print('regs,ins,outs,tries',*[h(code+x) for x in (0,2,4,6)])
    units=struct.unpack_from('<'+'H'*u(code+12),b,code+16);p0=0
    while p0<len(units):
     op=units[p0]&255;w=1;ref=''
     if 0x52<=op<=0x6d:w=2;ref=fields[units[p0+1]]
     elif 0x6e<=op<=0x72 or 0x74<=op<=0x78:w=3;ref=methods[units[p0+1]]
     elif op in (0x1c,0x1f,0x20,0x22,0x23):w=2;ref=types[units[p0+1]]
     elif op==0x1a:w=2;ref=repr(strings[units[p0+1]])
     elif op in (0x13,0x15,0x16,0x19,0x1a,0x29,0x2d,0x2e,0x2f,0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x3a,0x3b,0x3c,0x3d):w=2
     elif op in (0x02,0x05,0x08) or 0x44<=op<=0x51 or 0x90<=op<=0xaf or 0xd0<=op<=0xe2:w=2
     elif op in (0x03,0x06,0x09,0x14,0x17,0x1b,0x24,0x25,0x26,0x2a,0x2b,0x2c):w=3
     elif op==0x18:w=5
     elif op==0 and units[p0]==0x100:w=4+units[p0+1]*2
     elif op==0 and units[p0]==0x200:w=2+units[p0+1]*4
     elif op==0 and units[p0]==0x300:w=4+(units[p0+1]*(units[p0+2]+65536*units[p0+3])+1)//2
     print(f'{p0:04x}', ' '.join(f'{x:04x}' for x in units[p0:p0+w]),ref);p0+=w
