#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
javac --release 17 --add-modules jdk.httpserver -d "$TMP" $(find core/src/main/java -name '*.java') tests/EngineIntegration.java tests/EngineBenchmark.java tests/LargeResume.java tests/LiveAutoBenchmark.java tests/HyperBenchmark.java
case "${1:-benchmark}" in
  benchmark) java --add-modules jdk.httpserver -cp "$TMP" EngineBenchmark ;;
  smart) java --add-modules jdk.httpserver -cp "$TMP" LiveAutoBenchmark ;;
  large) java --add-modules jdk.httpserver -cp "$TMP" LargeResume ;;
  large-direct) java --add-modules jdk.httpserver -cp "$TMP" LargeResume direct ;;
  large-pipeline) java --add-modules jdk.httpserver -cp "$TMP" LargeResume pipeline ;;
  hyper) java --add-modules jdk.httpserver -cp "$TMP" HyperBenchmark ;;
  *) echo 'Use benchmark, smart, large, large-direct, large-pipeline or hyper'; exit 2 ;;
esac
