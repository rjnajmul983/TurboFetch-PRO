#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP=$(mktemp -d);trap 'rm -rf "$TMP"' EXIT
for version in Ultimate Extreme; do
  src=core/src/main/java; [[ "$version" != Ultimate ]] || src=baseline/java
  mkdir -p "$TMP/$version"
  javac --release 17 --add-modules jdk.httpserver -d "$TMP/$version" $(find "$src" -name '*.java') tests/EngineIntegration.java tests/ExtremeBenchmark.java
done
printf '%s\n' 'record,version,scenario,trial,completion_seconds,MiB_per_second,range_requests,final_ranges,data_syncs,checkpoint_writes,integrity'
for scenario in ${BENCH_SCENARIOS:-fast delayed request-latency}; do
 for trial in 1 2 3; do
  order=(Ultimate Extreme); [[ "$trial" != 2 ]] || order=(Extreme Ultimate)
  for version in "${order[@]}"; do
   java -Xmx768m --add-modules jdk.httpserver -cp "$TMP/$version" ExtremeBenchmark "$version" "$scenario" "$trial"
  done
 done
done
