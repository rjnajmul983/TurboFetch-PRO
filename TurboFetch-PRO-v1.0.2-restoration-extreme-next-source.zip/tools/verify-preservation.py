#!/usr/bin/env python3
import sys,zipfile,struct,re

def dex_classes(b):
 u=lambda p:struct.unpack_from('<I',b,p)[0]
 def string(i):
  p=u(u(60)+4*i)
  while b[p]&128:p+=1
  p+=1;return b[p:b.index(0,p)].decode('utf8','replace')
 def typ(i):return string(u(u(68)+4*i))
 return {typ(u(u(100)+32*i)) for i in range(u(96))}
def is_sig(n):return n.upper()=='META-INF/MANIFEST.MF' or (n.upper().startswith('META-INF/') and n.upper().endswith(('.SF','.RSA','.DSA','.EC')))
with zipfile.ZipFile(sys.argv[1]) as orig,zipfile.ZipFile(sys.argv[2]) as built:
 original=set(); output=set()
 for n in orig.namelist():
  if is_sig(n):continue
  assert n in built.namelist(),f'Missing {n}'
  a,b=orig.read(n),built.read(n)
  if n in ('classes3.dex','classes4.dex','classes6.dex','classes7.dex','classes8.dex'):
   assert dex_classes(a)==dex_classes(b),f'Original classes changed in {n}'
  elif n!='AndroidManifest.xml':assert a==b,f'Original entry modified: {n}'
  if re.fullmatch(r'classes\d*\.dex',n):original|=dex_classes(a);output|=dex_classes(b)
 bridge=dex_classes(built.read('classes9.dex'))
 assert bridge and all(c.startswith('Lcom/turbofetch/core/') for c in bridge),f'Unexpected injected classes: {bridge}'
 assert not (output&bridge),'Duplicate class definitions'
 assert original==output
 for suffix in ['browser/BrowserActivity;','browser/BrowserFileProbe;','torrent/TorrentEngine;','ftp/FtpEngine;','engine/TurboEngine;','stream/StreamAssembler;']:
  assert 'Lcom/turbofetch/app/'+suffix in output, suffix
 print(f'PASS: {len(original)} original class definitions retained; {len(bridge)} new engine/bridge classes; all non-patched original files identical')
 print('PASS: Browser, BrowserFileProbe, Torrent, FTP, all four native libraries and original resources retained')
