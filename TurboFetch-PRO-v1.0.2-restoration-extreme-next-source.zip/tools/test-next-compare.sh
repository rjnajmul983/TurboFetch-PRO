#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP=$(mktemp -d);trap 'rm -rf "$TMP"' EXIT
for version in Extreme Next; do
 src=core/src/main/java; [[ "$version" != Extreme ]] || src=baseline/extreme-java
 mkdir -p "$TMP/$version"
 javac --release 17 --add-modules jdk.httpserver -d "$TMP/$version" $(find "$src" -name '*.java') tests/EngineIntegration.java tests/ExtremeBenchmark.java
done
printf '%s\n' 'record,version,scenario,trial,completion_seconds,MiB_per_second,range_requests,final_ranges,data_syncs,checkpoint_writes,integrity'
for scenario in ${BENCH_SCENARIOS:-fast delayed request-latency}; do
 for trial in ${BENCH_TRIALS:-1 2 3}; do
  order=(Extreme Next Pipeline); [[ "$trial" != 2 ]] || order=(Pipeline Next Extreme); [[ "$trial" != 3 ]] || order=(Next Extreme Pipeline)
  for v in "${order[@]}"; do
   cp="$TMP/$v"; [[ "$v" != Pipeline ]] || cp="$TMP/Next"
   java -Xmx768m --add-modules jdk.httpserver -cp "$cp" ExtremeBenchmark "$v" "$scenario" "$trial"
  done
 done
done
