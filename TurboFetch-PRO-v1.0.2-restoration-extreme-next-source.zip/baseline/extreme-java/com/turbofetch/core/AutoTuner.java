package com.turbofetch.core;

/** Feedback controller: compare steady-state useful throughput at candidate worker counts.
 * Each sample is a full observation window, not an individual packet or HTTP request. */
public final class AutoTuner {
    private static final int[] LEVELS={1,2,4,8,12,16,24,32};
    private int desired,best,baselineCount,windows,settle=1,cooldown,stableRounds;
    private double sum,bestRate,baseline;
    private boolean exploring,down,preferDown;
    public AutoTuner(int cap,int learned){desired=Math.max(1,Math.min(cap,learned>0?learned:4));best=desired;}
    public int desired(){return desired;}
    public int best(){return best;}
    public double bestRate(){return bestRate;}
    public int samples(){return baselineCount;}
    private static int next(int n,int cap,boolean lower){
        if(lower){for(int i=LEVELS.length-1;i>=0;i--)if(LEVELS[i]<n)return LEVELS[i];return 1;}
        for(int level:LEVELS)if(level>n)return Math.min(cap,level);return cap;
    }
    private void change(int n){desired=n;windows=0;sum=0;settle=1;}
    public void reset(int n){best=desired=Math.max(1,n);bestRate=baseline=0;baselineCount=0;exploring=false;preferDown=false;stableRounds=0;cooldown=3;change(desired);}
    public int observe(double rate,int active,int cap,boolean nearEnd){
        cap=Math.max(1,cap);
        if(desired>cap){reset(cap);return desired;}
        if(nearEnd||rate<=0||active!=desired)return desired;
        if(settle>0){settle--;return desired;}
        sum+=rate;if(++windows<2)return desired;
        double measured=sum/windows;sum=0;windows=0;baselineCount++;
        if(exploring){
            // Prefer fewer workers if throughput remains within 5%; require a real gain to go up.
            boolean accept=down?measured>=baseline*.95:measured>baseline*1.08;
            if(accept){best=desired;bestRate=measured;baseline=measured;cooldown=1;preferDown=down;}
            else{change(best);cooldown=2;preferDown=!down;}
            exploring=false;return desired;
        }
        best=desired;bestRate=bestRate==0?measured:.65*bestRate+.35*measured;baseline=measured;
        if(cooldown>0){cooldown--;return desired;}
        // Periodically explore a lower level; otherwise explore upward when room exists.
        down=preferDown||(++stableRounds%3==0)||desired>=cap;
        int candidate=next(desired,cap,down);
        if(candidate==desired){down=!down;candidate=next(desired,cap,down);}
        if(candidate!=desired){exploring=true;change(candidate);}
        return desired;
    }
    public int bufferBytes(long rate,int workers){long each=rate/Math.max(1,workers);return each>=16L*1024*1024?512*1024:each>=4L*1024*1024?256*1024:each>=512*1024?128*1024:64*1024;}
}
