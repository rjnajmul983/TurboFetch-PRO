package com.turbofetch.core;
/** Conservative automatic geometry for new direct jobs; persisted jobs keep their original ranges. */
public final class ExtremePolicy {
    private static final long M=1048576L;
    private ExtremePolicy(){}
    public static long segmentSize(long total,int cap,int learned){
        int target=Math.max(1,Math.min(cap,learned>0?Math.max(learned,4):8));
        long ideal=Math.max(M,total/Math.max(2,target*3L));
        long size=M;while(size<ideal&&size<256*M)size*=2;
        // Maintain sufficient independent work for rapid scaling. Bound metadata separately in Engine.
        return Math.min(size,Math.max(M,total/Math.max(1,Math.min(cap,16))));
    }
    public static long checkpointBytes(long speed){return speed>=32*M?32*M:speed>=8*M?16*M:8*M;}
    public static int connectTimeout(String network){return "Wi-Fi".equals(network)||"Ethernet".equals(network)?10000:16000;}
    public static int readTimeout(String network){return "Wi-Fi".equals(network)||"Ethernet".equals(network)?15000:25000;}
}
