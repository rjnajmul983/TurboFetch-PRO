package com.turbofetch.core;
public final class PerformancePolicy {
 private int cap=32,recovery=0;
 public static int thermalLimit(int thermal){return thermal>=5?1:thermal>=4?2:thermal>=3?4:thermal>=2?12:32;}
 public synchronized int update(int thermal,boolean saver,boolean low){int target=Math.min(thermalLimit(thermal),Math.min(saver?8:32,low?4:32));if(target<cap){cap=target;recovery=0;}else if(target>cap){if(++recovery>=20){cap=Math.min(target,cap*2);recovery=0;}}else recovery=0;return cap;}
 public static int initialWorkers(long remain,int learned,int max){int sizeCap=remain<0?4:remain<4L*1048576?1:remain<16L*1048576?4:remain<64L*1048576?8:32;return Math.max(1,Math.min(Math.min(max,sizeCap),learned>0?learned:4));}
 public static int initialWorkers(long remain,int learned,int max,String network){
  // A cautious cold start for large, unmetered-style transports; actual tuning still measures useful throughput.
  int hint=learned;
  if(hint<=0&&remain>=128L*1048576&&( "Wi-Fi".equals(network)||"Ethernet".equals(network)))hint=8;
  return initialWorkers(remain,hint,max);
 }
}
