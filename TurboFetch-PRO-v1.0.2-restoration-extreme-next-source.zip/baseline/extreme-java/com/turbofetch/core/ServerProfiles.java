package com.turbofetch.core;
import java.io.*;
import java.net.URI;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Local, bounded, expiring performance memory. No URL paths, query tokens or credentials stored. */
public final class ServerProfiles {
    private static final long TTL=7L*24*60*60*1000;
    private static final int MAX=128;
    private final File directory;
    public ServerProfiles(File root){directory=new File(root,".profiles");}
    private File key(String url,String transport)throws Exception{
        URI u=URI.create(url);String scheme=u.getScheme().toLowerCase(Locale.ROOT);int port=u.getPort()<0?(scheme.equals("https")?443:80):u.getPort();
        String identity=scheme+"://"+u.getHost().toLowerCase(Locale.ROOT)+":"+port+"|"+transport;
        byte[] hash=MessageDigest.getInstance("SHA-256").digest(identity.getBytes(StandardCharsets.UTF_8));StringBuilder name=new StringBuilder();for(byte b:hash)name.append(String.format(Locale.ROOT,"%02x",b&255));return new File(directory,name+".properties");
    }
    public int load(String url,String network){synchronized(ServerProfiles.class){try{
        Properties p=new Properties();try(InputStream in=new FileInputStream(key(url,network))){p.load(in);}long age=System.currentTimeMillis()-Long.parseLong(p.getProperty("time"));int n=Integer.parseInt(p.getProperty("workers"));return age>=0&&age<TTL&&n>=1&&n<=32?n:0;
    }catch(Exception e){return 0;}}}
    public void save(String url,String network,int count,double rate,int samples){if(samples<2||rate<=0||count<1||count>32)return;synchronized(ServerProfiles.class){try{
        if(!directory.isDirectory()&&!directory.mkdirs())return;Properties p=new Properties();p.setProperty("time",Long.toString(System.currentTimeMillis()));p.setProperty("workers",Integer.toString(count));p.setProperty("rate",Long.toString((long)rate));p.setProperty("samples",Integer.toString(samples));Job.atomicProperties(key(url,network),p);
        File[] files=directory.listFiles((d,n)->n.endsWith(".properties"));if(files!=null&&files.length>MAX){Arrays.sort(files,Comparator.comparingLong(File::lastModified));for(int i=0;i<files.length-MAX;i++)files[i].delete();}
    }catch(Exception ignored){/* performance hint only; downloads must not fail because of cache */}}}
    public void clear(){synchronized(ServerProfiles.class){File[] files=directory.listFiles();if(files!=null)for(File f:files)f.delete();}}
}
