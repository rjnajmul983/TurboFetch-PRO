package com.turbofetch.core;
import java.io.*;
import java.util.concurrent.*;
/** One outstanding write per owner, at most four owners globally. Caller retains buffer until drain. */
final class AsyncDiskWriter implements AutoCloseable {
    private static final Semaphore SLOTS=new Semaphore(4);
    private static final ExecutorService POOL=Executors.newFixedThreadPool(4,r->{Thread t=new Thread(r,"turbo-disk-writer");t.setDaemon(true);return t;});
    private Future<Integer> pending; private boolean closed;
    private AsyncDiskWriter(){}
    static AsyncDiskWriter acquire(){return SLOTS.tryAcquire()?new AsyncDiskWriter():null;}
    void submit(RandomAccessFile file,byte[] data,int count){if(closed||pending!=null)throw new IllegalStateException("Outstanding write");pending=POOL.submit(()->{file.write(data,0,count);return count;});}
    int drain()throws IOException {if(pending==null)return 0;Future<Integer> f=pending;pending=null;boolean interrupted=false;try{for(;;){try{return f.get();}catch(InterruptedException e){interrupted=true;}catch(ExecutionException e){Throwable cause=e.getCause();throw cause instanceof IOException?(IOException)cause:new IOException("Disk writer failed",cause);}}}finally{if(interrupted)Thread.currentThread().interrupt();}}
    public void close()throws IOException{if(closed)return;try{drain();}finally{closed=true;SLOTS.release();}}
}
