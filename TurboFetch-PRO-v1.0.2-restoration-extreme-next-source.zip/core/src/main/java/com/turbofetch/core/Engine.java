package com.turbofetch.core;

import java.io.*;
import java.net.*;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.regex.*;

/** HTTP range engine. No Android dependencies: the actual engine is host-testable. */
public final class Engine {
    public interface Metadata { void accept(long size,String mime,String disposition) throws IOException; }
    public interface Publisher { String publish(Job job, Control control) throws IOException; }
    public interface Transport {
        HttpURLConnection open(URL target, boolean verifiedRange) throws IOException;
        default void failed(HttpURLConnection connection, IOException error) {}
        default void transferred(HttpURLConnection connection,long bytes,long nanos) {}
        default void closed(HttpURLConnection connection) {}
        default String description(){return "Platform HTTP";}
    }
    public static final class Control {
        public Transport transport=(target,verifiedRange)->(HttpURLConnection)target.openConnection();
        private final AtomicBoolean paused=new AtomicBoolean();
        public volatile int workerBudget=32;
        public volatile String network="unknown";
        public boolean dynamicRanges=false,directStorage=false;
        public boolean extreme=true;
        public final AdaptiveLatency latency=new AdaptiveLatency();
        /** 0: conservative synchronous default, 1: force pipeline for controlled tests. */
        public int pipelineMode=0;
        public boolean retainPartsAfterPublish=false,fixedWorkers=false;
        public String cookie="",referer="";
        public int speedLimitKiB=0;
        public Metadata metadata=(size,mime,disposition)->{};
        private long nextRate;
        void pace(int n)throws IOException {
            if(speedLimitKiB<=0)return;
            long due; synchronized(this){long now=System.nanoTime();nextRate=Math.max(now,nextRate)+(long)(n*1e9/(speedLimitKiB*1024.0));due=nextRate;}
            while(due>System.nanoTime()){check();sleep(this,Math.max(1,Math.min(100,TimeUnit.NANOSECONDS.toMillis(due-System.nanoTime()))));}
        }
        private final Set<HttpURLConnection> sockets=ConcurrentHashMap.newKeySet();
        void track(HttpURLConnection c)throws IOException{sockets.add(c);if(paused()){close(c);throw new Paused();}}
        void close(HttpURLConnection c){sockets.remove(c);try{c.disconnect();}finally{transport.closed(c);}}
        public void pause(){paused.set(true); /* disconnect outside caller/UI thread */ for(HttpURLConnection c:sockets){Thread t=new Thread(()->close(c),"transfer-cancel");t.setDaemon(true);t.start();}}
        public boolean paused(){return paused.get();}
        public void check() throws IOException {if(paused())throw new Paused();}
    }
    private static final class Paused extends IOException {Paused(){super("Paused");}}
    private static final class Restart extends IOException {Restart(String s){super(s);}}
    private static final class Permanent extends IOException {Permanent(String s){super(s);}}
    private static final class Retry extends IOException {final long delay;Retry(String s,long delay){super(s);this.delay=delay;}}
    private static final Pattern RANGE=Pattern.compile("bytes (\\d+)-(\\d+)/(\\d+)",Pattern.CASE_INSENSITIVE);
    private static final long MIB=1024L*1024, CHECKPOINT=4*MIB;
    private static final int BUFFER=128*1024;
    // Shared by concurrent jobs in this process; use monotonic deadlines and bounded storage.
    private static final Map<String,Long> ORIGIN_HOLD=new HashMap<>();
    private static String origin(URL u){return u.getProtocol().toLowerCase(Locale.ROOT)+"://"+u.getHost().toLowerCase(Locale.ROOT)+":"+(u.getPort()<0?u.getDefaultPort():u.getPort());}
    private static synchronized void hold(URL url,long ms){long now=System.nanoTime();ORIGIN_HOLD.entrySet().removeIf(e->e.getValue()<=now);String k=origin(url);if(ORIGIN_HOLD.size()>=1024&&!ORIGIN_HOLD.containsKey(k))return;long deadline=now+TimeUnit.MILLISECONDS.toNanos(Math.min(ms,86_400_000));ORIGIN_HOLD.merge(k,deadline,Math::max);}
    private static void awaitOrigin(URL url,Control control)throws IOException{while(true){long left;synchronized(Engine.class){left=ORIGIN_HOLD.getOrDefault(origin(url),0L)-System.nanoTime();}if(left<=0)return;if(left>TimeUnit.SECONDS.toNanos(120))throw new Permanent("Origin cooling down; retry later");sleep(control,Math.max(1,Math.min(200,TimeUnit.NANOSECONDS.toMillis(left))));}}
    private static final class Probe {long total;boolean range;String etag="",modified="",mime="",disposition="";}
    private static final class Gate {
        private int limit,active;private long holdUntil;
        Gate(int n){limit=n;}
        synchronized void acquire(Control c,AtomicReference<IOException> failure)throws IOException{
            while(active>=limit||System.currentTimeMillis()<holdUntil){c.check();if(failure.get()!=null)throw new Paused();try{wait(200);}catch(InterruptedException e){Thread.currentThread().interrupt();throw new Paused();}}
            c.check();if(failure.get()!=null)throw new Paused();active++;
        }
        synchronized void release(){active--;notifyAll();}
        synchronized int limit(){return limit;}
        synchronized int active(){return active;}
        synchronized void tune(int n){if(System.currentTimeMillis()>=holdUntil)limit=Math.max(1,n);notifyAll();}
        synchronized boolean cooling(){return System.currentTimeMillis()<holdUntil;}
        synchronized void awaitCooldown(Control c)throws IOException{while(cooling()){c.check();try{wait(200);}catch(InterruptedException e){Thread.currentThread().interrupt();throw new Paused();}}}
        synchronized void backoff(long delay){limit=Math.max(1,limit/2);holdUntil=Math.max(holdUntil,System.currentTimeMillis()+delay);notifyAll();}
    }
    /** Waiting workers can request a cooperative split; only the current owner commits and splits. */
    private static final class Dispatcher {
        final Job job;final boolean enabled;int next,owned,waiting;
        Dispatcher(Job job,boolean enabled){this.job=job;this.enabled=enabled;}
        synchronized int claim(Control c,AtomicReference<IOException> failure)throws IOException{
            while(next>=job.partCount&&owned>0&&enabled){c.check();if(failure.get()!=null)return -1;waiting++;try{wait(200);}catch(InterruptedException e){Thread.currentThread().interrupt();throw new Paused();}finally{waiting--;}}
            if(next>=job.partCount)return -1;owned++;return next++;
        }
        synchronized void done(){owned--;notifyAll();}
        synchronized boolean canSplit(Gate gate){return enabled&&waiting>0&&next>=job.partCount&&gate.active()<gate.limit()&&job.partCount<8192;}
        synchronized boolean split(int n,long pos,long left)throws IOException{if(next<job.partCount||waiting==0)return false;int result=job.split(n,pos,left);notifyAll();return result>=0;}
    }
    private static String header(HttpURLConnection c,String key){String s=c.getHeaderField(key);return s==null?"":s.trim();}
    private static String strongEtag(HttpURLConnection c){String e=header(c,"ETag");return e.startsWith("\"")&&e.endsWith("\"")?e:"";}
    private static String safeModified(HttpURLConnection c){String m=header(c,"Last-Modified");long date=c.getHeaderFieldDate("Date",-1),last=c.getHeaderFieldDate("Last-Modified",-1);return last>=0&&date-last>=60_000?m:"";}
    private static long contentLength(HttpURLConnection c){try{return Long.parseLong(header(c,"Content-Length"));}catch(NumberFormatException e){return -1;}}
    private static long[] parseRange(String s)throws IOException{
        Matcher m=RANGE.matcher(s);if(!m.matches())throw new Restart("Invalid Content-Range: "+s);
        try{return new long[]{Long.parseLong(m.group(1)),Long.parseLong(m.group(2)),Long.parseLong(m.group(3))};}catch(NumberFormatException e){throw new Restart("Invalid range numbers");}
    }
    private static HttpURLConnection connect(Job j,String range,String validator,Control control)throws IOException{
        String url=j.url;
        for(int redirects=0;redirects<=8;redirects++){
            control.check();Store.validate(url);
            URL target=new URL(url);awaitOrigin(target,control);j.requests.incrementAndGet();HttpURLConnection c=control.transport.open(target,range!=null && validator!=null && validator.startsWith("\"") && !j.sha256.isEmpty() && origin(target).equals(origin(new URL(j.url))));
            try {
                control.track(c);c.setInstanceFollowRedirects(false);c.setConnectTimeout(control.extreme?control.latency.connect(control.network):12_000);c.setReadTimeout(control.extreme?control.latency.read(control.network):12_000);c.setUseCaches(false);
                c.setRequestProperty("Accept-Encoding","identity");
                c.setRequestProperty("User-Agent",j.userAgent.isEmpty()?"TurboFetchPRO/1.0":j.userAgent);
                if(origin(target).equals(origin(new URL(j.url)))) {
                    if(!control.cookie.isEmpty())c.setRequestProperty("Cookie",control.cookie);
                    if(!control.referer.isEmpty())c.setRequestProperty("Referer",control.referer);
                }
                if(range!=null)c.setRequestProperty("Range",range);if(validator!=null&&!validator.isEmpty())c.setRequestProperty("If-Range",validator);
                long responseStart=System.nanoTime();int code=c.getResponseCode();if(code>=200&&code<400)control.latency.observe(control.network,TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-responseStart));
                if(code==301||code==302||code==303||code==307||code==308){String loc=header(c,"Location");if(loc.isEmpty())throw new Permanent("Redirect has no Location");String next=new URL(new URL(url),loc).toString();if(url.startsWith("https:")&&!next.startsWith("https:"))throw new Permanent("HTTPS downgrade redirect blocked");url=next;control.close(c);continue;}
                return c;
            }catch(IOException|RuntimeException e){IOException wrapped=e instanceof IOException?(IOException)e:new IOException("Transport configuration failed",e);if(wrapped instanceof SocketTimeoutException)control.latency.timeout(control.network);try{control.transport.failed(c,wrapped);}finally{control.close(c);}throw wrapped;}
        }
        throw new Permanent("Too many redirects");
    }
    private static long retryDelay(HttpURLConnection c){String s=header(c,"Retry-After");try{return Math.max(1000,Math.multiplyExact(Long.parseLong(s),1000));}catch(Exception e){long t=c.getHeaderFieldDate("Retry-After",-1);return t>0?Math.max(1000,t-System.currentTimeMillis()):2000;}}
    private static void status(HttpURLConnection c)throws IOException{
        int code=c.getResponseCode();if(code==429||code==503){long delay=retryDelay(c);hold(c.getURL(),delay);if(delay>120_000)throw new Permanent("HTTP "+code+": server requests a long cooldown; resume later");throw new Retry("HTTP "+code,delay);}
        if(code>=500||code==408)throw new Retry("HTTP "+code,1500);
        if(code==401||code==403||code==404||code==410)throw new Permanent("HTTP "+code+"; check or replace URL");
        if(code!=200&&code!=206)throw new Permanent("HTTP "+code);
        String enc=header(c,"Content-Encoding");if(!enc.isEmpty()&&!enc.equalsIgnoreCase("identity"))throw new Permanent("Unexpected content encoding: "+enc);
    }
    private static void sleep(Control control,long ms)throws IOException{long end=System.nanoTime()+TimeUnit.MILLISECONDS.toNanos(ms);while(System.nanoTime()<end){control.check();try{Thread.sleep(Math.min(200,Math.max(1,TimeUnit.NANOSECONDS.toMillis(end-System.nanoTime()))));}catch(InterruptedException e){Thread.currentThread().interrupt();throw new Paused();}}}
    private static Probe probe(Job j,Control control)throws IOException{
        for(int attempt=0;;attempt++){
            HttpURLConnection c=null;
            try{
                c=connect(j,"bytes=0-0",null,control);int code=c.getResponseCode();Probe p=new Probe();p.etag=strongEtag(c);p.modified=safeModified(c);p.mime=header(c,"Content-Type");p.disposition=header(c,"Content-Disposition");
                if(code==416&&header(c,"Content-Range").equalsIgnoreCase("bytes */0")){p.total=0;return p;}
                status(c);
                if(code==206){long[] r=parseRange(header(c,"Content-Range"));if(r[0]!=0||r[1]!=0||r[2]<1)throw new Restart("Server returned invalid probe range");p.total=r[2];p.range=!p.etag.isEmpty()||!p.modified.isEmpty()||!j.sha256.isEmpty();}
                else {p.total=contentLength(c);p.range=false;}
                return p;
            }catch(Permanent|Restart|Paused e){throw e;}catch(IOException e){if(attempt>=2)throw e;long delay=e instanceof Retry?((Retry)e).delay:1000L<<attempt;sleep(control,delay);}
            finally{if(c!=null)control.close(c);}
        }
    }
    private static boolean same(Job j,Probe p){if(j.total!=p.total)return false;if(!j.etag.isEmpty())return j.etag.equals(p.etag);if(!j.modified.isEmpty())return j.modified.equals(p.modified);return !j.sha256.isEmpty();}
    private static void configure(Job j,Probe p,Control control)throws IOException{
        j.resetGeometry();j.direct=control.directStorage&&p.range&&p.total>0;
        if(j.direct){try(RandomAccessFile f=new RandomAccessFile(j.directFile(),"rw")){f.seek(0);}catch(IOException e){j.direct=false;}}
        j.total=p.total;j.ranged=p.range&&p.total>0;j.etag=p.etag;j.modified=p.modified;
        // 8–32 MiB chunks, dynamically assigned to idle workers. Bound metadata for huge files.
        long nominal=j.total<64*MIB?Math.max(MIB,(j.total+Math.max(1,j.connections)*2L-1)/(Math.max(1,j.connections)*2L)):j.total<1024*MIB?4*MIB:8*MIB;
        if(control.extreme&&j.direct)nominal=ExtremePolicy.segmentSize(j.total,j.connections,new ServerProfiles(j.dir.getParentFile()).load(j.url,control.network));
        j.blockSize=j.ranged?Math.max(nominal,(j.total-1)/4096+1):0;
        j.partCount=j.ranged?(int)((j.total-1)/j.blockSize+1):1;if(j.direct&&control.extreme)j.initJournal();j.save();
    }
    private static boolean allDone(Job j)throws IOException{
        if(j.partCount==0||j.total<0)return false;
        for(int i=0;i<j.partCount;i++)if(j.recover(i)!=j.size(i))return false;
        return true;
    }
    public void run(Job j,Control control,Publisher publisher){
        ScheduledExecutorService monitor=null;AtomicReference<IOException> failure=new AtomicReference<>();
        try{
            j.inFlight=true;j.state=Job.State.RUNNING;j.error="";j.save();long have=j.recoverAll();control.check();
            if(!allDone(j)){
                Probe p=probe(j,control);control.metadata.accept(p.total,p.mime,p.disposition);
                if(have>0){if(!j.ranged||!p.range||!same(j,p))throw new Restart("Cannot safely resume: server does not support matching byte ranges or file changed. Saved bytes retained.");}
                else {j.removeParts();configure(j,p,control);}
                if(j.total>have&&j.dir.getUsableSpace()<j.total-have)throw new IOException("Insufficient storage for remaining download; saved data retained");
                if(j.total==0){try(RandomAccessFile f=new RandomAccessFile(j.data(0),"rw")){f.getFD().sync();}j.commit(0,0);}
                else {
                    int max=j.ranged?Math.max(1,Math.min(j.connections,control.dynamicRanges?(int)Math.min(32,Math.max(j.partCount,j.total/MIB)):j.partCount)):1;
                    ServerProfiles profiles=new ServerProfiles(j.dir.getParentFile());
                    int initialCap=Math.max(1,Math.min(max,control.workerBudget));
                    int learned=profiles.load(j.url,control.network);
                    if(control.dynamicRanges)learned=PerformancePolicy.initialWorkers(j.total-have,learned,initialCap,control.network);
                    if(control.dynamicRanges&&j.total>0&&j.total<4*MIB)learned=1;
                    AutoTuner tuner=new AutoTuner(initialCap,learned);
                    Gate gate=new Gate(control.fixedWorkers?initialCap:tuner.desired());Dispatcher dispatcher=new Dispatcher(j,control.dynamicRanges);CheckpointBatch batch=j.journal?new CheckpointBatch(j):null;
                    final long[] last={j.bytes.get(),System.nanoTime(),0};
                    final String[] lastNetwork={control.network};
                    j.workerLimit=gate.limit();
                    monitor=Executors.newSingleThreadScheduledExecutor();
                    monitor.scheduleAtFixedRate(()->{
                        long now=System.nanoTime(),b=j.bytes.get();long speed=(long)(Math.max(0,b-last[0])*1e9/Math.max(1,now-last[1]));
                        j.speed=speed;j.workers=gate.active();last[0]=b;last[1]=now;
                        int cap=Math.max(1,Math.min(max,control.workerBudget));
                        if(!Objects.equals(lastNetwork[0],control.network)){lastNetwork[0]=control.network;int hint=profiles.load(j.url,control.network);tuner.reset(PerformancePolicy.initialWorkers(j.total-b,hint,cap,control.network));gate.tune(tuner.desired());last[2]=0;}
                        if(gate.cooling()||gate.limit()!=tuner.desired())tuner.reset(Math.min(cap,gate.limit()));
                        boolean nearEnd=j.total>=0&&j.total-b<Math.max(2*MIB,speed*2);
                        if(!gate.cooling())gate.tune(control.fixedWorkers?cap:tuner.observe(speed,gate.active(),cap,nearEnd));
                        j.workerLimit=gate.limit();j.bufferBytes=tuner.bufferBytes(speed,gate.active());
                        // Only persist adequately sampled stable settings, not end-of-file or cooldown samples.
                        if(!gate.cooling()&&!nearEnd&&gate.limit()==tuner.best()&&tuner.samples()>=2&&tuner.samples()!=last[2]&&j.connections==32&&control.workerBudget>=max){
                            profiles.save(j.url,control.network,tuner.best(),tuner.bestRate(),tuner.samples());last[2]=tuner.samples();
                        }
                    },1,1,TimeUnit.SECONDS);
                    ExecutorService pool=Executors.newFixedThreadPool(max);List<Future<?>> futures=new ArrayList<>();
                    try{
                        for(int i=0;i<max;i++)futures.add(pool.submit(()->{
                            while(!control.paused()&&failure.get()==null){
                                int n=-1;boolean acquired=false;
                                try{n=dispatcher.claim(control,failure);if(n<0)return;if(j.size(n)>=0&&j.recover(n)==j.size(n))continue;gate.acquire(control,failure);acquired=true;transferWithRetry(j,n,control,failure,gate,dispatcher,batch);}
                                catch(IOException e){if(!(e instanceof Paused))failure.compareAndSet(null,e);return;}
                                catch(RuntimeException e){failure.compareAndSet(null,new IOException("Worker failed",e));return;}
                                finally{if(acquired)gate.release();if(n>=0)dispatcher.done();}
                            }
                        }));
                        for(Future<?> f:futures)try{f.get();}catch(InterruptedException e){control.pause();Thread.currentThread().interrupt();throw new Paused();}catch(ExecutionException e){throw new IOException("Worker failed",e);}
                    }finally{pool.shutdown();while(!pool.isTerminated()){try{pool.awaitTermination(1,TimeUnit.SECONDS);}catch(InterruptedException e){control.pause();Thread.interrupted();}}}
                    if(failure.get()!=null)throw failure.get();control.check();
                }
            }
            control.check();j.validateGeometry();j.recoverAll();if(!allDone(j))throw new IOException("Download incomplete; committed data retained");
            j.state=Job.State.FINALIZING;j.speed=0;j.workers=0;j.save();
            if(!j.sha256.isEmpty()&&!j.sha256.equals(sha256(j,control)))throw new Restart("SHA-256 mismatch; partial data retained. Restart or remove after review.");
            control.check();j.output=publisher.publish(j,control);j.state=Job.State.COMPLETED;j.completedAt=System.currentTimeMillis();j.bytes.set(j.total);j.error="";j.save();
            if(!control.retainPartsAfterPublish)try{j.removeParts();}catch(IOException ignored){}
        }catch(IOException|RuntimeException e){
            j.state=control.paused()||e instanceof Paused?(j.recoverAutomatically?Job.State.WAITING_NETWORK:Job.State.PAUSED):e instanceof Restart?Job.State.NEEDS_RESTART:Job.State.FAILED;
            j.error=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
            try{j.recoverAll();j.save();}catch(IOException recovery){j.error+="; checkpoint recovery: "+recovery.getMessage();}
        }finally{if(monitor!=null)monitor.shutdownNow();j.speed=0;j.workers=0;j.workerLimit=0;j.inFlight=false;}
    }
    private static void transferWithRetry(Job j,int n,Control c,AtomicReference<IOException> failure,Gate gate,Dispatcher dispatcher,CheckpointBatch batch)throws IOException{
        for(int attempt=0;;attempt++){
            c.check();if(failure.get()!=null)throw new Paused();gate.awaitCooldown(c);if(failure.get()!=null)throw new Paused();long at=j.recover(n);if(j.size(n)>=0&&at==j.size(n))return;
            if(at>0&&!j.ranged)throw new Restart("Server cannot safely resume this partial file. Restart requires confirmation.");
            try{transfer(j,n,at,c,failure,gate,dispatcher,batch);return;}
            catch(Paused|Restart|Permanent e){throw e;}
            catch(IOException e){if(attempt>=3)throw e;long delay=e instanceof Retry?((Retry)e).delay:Math.min(10_000,(1000L<<attempt)+ThreadLocalRandom.current().nextInt(400));if(e instanceof Retry)gate.backoff(delay);sleep(c,delay);}
        }
    }
    private static void transfer(Job j,int n,long at,Control control,AtomicReference<IOException> failure,Gate gate,Dispatcher dispatcher,CheckpointBatch batch)throws IOException{
        String range=j.ranged?"bytes="+(j.start(n)+at)+"-"+(j.start(n)+j.size(n)-1):null;
        String validator=j.etag.isEmpty()?j.modified:j.etag;
        long transferStart=System.nanoTime();HttpURLConnection c=connect(j,range,validator,control);
        try {
            int code=c.getResponseCode();if(j.ranged&&(code==200||code==416))throw new Restart("Server refused saved byte range (HTTP "+code+"); data retained");status(c);
            String returned=header(c,"ETag");if(!j.etag.isEmpty()&&!returned.isEmpty()&&!j.etag.equals(returned))throw new Restart("ETag changed");
            String mod=header(c,"Last-Modified");if(j.etag.isEmpty()&&!j.modified.isEmpty()&&!mod.isEmpty()&&!j.modified.equals(mod))throw new Restart("Last-Modified changed");
            long expected=j.size(n);
            if(j.ranged){if(code!=206)throw new Restart("Expected HTTP 206");long[] r=parseRange(header(c,"Content-Range"));if(r[0]!=j.start(n)+at||r[1]!=j.start(n)+expected-1||r[2]!=j.total)throw new Restart("Content-Range does not match requested bytes");long cl=contentLength(c);if(cl>=0&&cl!=expected-at)throw new Restart("Range response length mismatch");}
            else {if(code!=200)throw new Restart("Unexpected partial response");long cl=contentLength(c);if(expected>=0&&cl>=0&&cl!=expected)throw new Restart("File size changed");}
            int buffer=Math.max(64*1024,Math.min(512*1024,j.bufferBytes));byte[] buf=control.extreme?BufferPool.take(buffer):new byte[buffer];long pos=at,last=at,lastSync=System.nanoTime();
            AsyncDiskWriter writer=control.pipelineMode==1&&j.direct&&batch!=null&&expected-at>=2*MIB?AsyncDiskWriter.acquire():null;
            try(AsyncDiskWriter ownedWriter=writer;RandomAccessFile out=new RandomAccessFile(j.storage(n),"rw");InputStream in=new BufferedInputStream(c.getInputStream(),buffer)){
                out.seek(j.position(n,at));boolean split=false;
                int pending=0;byte[] spare=writer==null?null:BufferPool.take(buffer);byte[] readBuffer=buf;
                try{
                    if(writer!=null){
                        // Read the next bounded buffer while the preceding buffer is written. Only
                        // the owning worker updates range progress after the write has completed.
                        while(pos+pending<expected||pending>0){
                            control.check();if(failure.get()!=null)throw new Paused();
                            int read=pos+pending<expected?in.read(readBuffer,0,(int)Math.min(readBuffer.length,expected-pos-pending)):0;
                            if(pending>0){int written=pending;pending=0;if(writer.drain()!=written)throw new IOException("Disk write mismatch");pos+=written;j.bytes.addAndGet(written);batch.written(n,pos,written,out,false);
                                if(!split&&expected-pos>=2*MIB&&dispatcher.canSplit(gate)){batch.written(n,pos,0,out,true);long left=pos+(expected-pos)/2;if(dispatcher.split(n,pos,left)){expected=left;split=true;}}
                            }
                            if(read<0){if(pos<expected)throw new EOFException("Unexpected end of response");break;}
                            if(read==0)continue;
                            if(read>expected-pos)throw new IOException("Prefetch exceeds owned range");
                            control.pace(read);writer.submit(out,readBuffer,read);j.pipelineWrites.incrementAndGet();pending=read;readBuffer=readBuffer==buf?spare:buf;
                        }
                    }else while(expected<0||pos<expected){control.check();if(failure.get()!=null)throw new Paused();int want=expected<0?buf.length:(int)Math.min(buf.length,expected-pos);int read=in.read(buf,0,want);if(read<0){if(expected>=0)throw new EOFException("Unexpected end of response");break;}if(read==0)continue;control.pace(read);out.write(buf,0,read);pos+=read;j.bytes.addAndGet(read);
                        if(batch!=null){batch.written(n,pos,read,out,false);}else if(pos-last>=CHECKPOINT||System.nanoTime()-lastSync>=2_000_000_000L){syncPart(j,out,n,pos);last=pos;lastSync=System.nanoTime();}
                        if(j.ranged&&!split&&expected-pos>=2*MIB&&dispatcher.canSplit(gate)){if(batch!=null)batch.written(n,pos,0,out,true);else syncPart(j,out,n,pos);long left=pos+(expected-pos)/2;if(dispatcher.split(n,pos,left)){expected=left;split=true;last=pos;lastSync=System.nanoTime();}}
                    }
                    if(!split&&expected>=0&&contentLength(c)<0&&in.read()!=-1){if(!j.direct)out.setLength(at);j.bytes.addAndGet(at-pos);pos=at;throw new Restart("Response contains extra bytes; unsafe response discarded");}
                }finally{
                    try{if(pending>0){int written=pending;pending=0;if(writer.drain()!=written)throw new IOException("Disk write mismatch");pos+=written;j.bytes.addAndGet(written);}}
                    finally{if(spare!=null)BufferPool.give(spare);if(batch!=null)batch.written(n,pos,0,out,true);else syncPart(j,out,n,pos);}
                }
            }finally{if(control.extreme)BufferPool.give(buf);}
            if(expected<0){j.total=pos;j.save();}
            control.transport.transferred(c,pos-at,System.nanoTime()-transferStart);
        }catch(IOException e){if(e instanceof SocketTimeoutException)control.latency.timeout(control.network);if(!(e instanceof Paused||e instanceof Restart||e instanceof Permanent||e instanceof Retry))control.transport.failed(c,e);throw e;}finally{control.close(c);}
    }
    private static void syncPart(Job j,RandomAccessFile out,int n,long pos)throws IOException{out.getFD().sync();j.dataSyncs.incrementAndGet();j.commit(n,pos);}
    /** Snapshot only writes that already finished; fsync shared file BEFORE publishing journal. */
    private static final class CheckpointBatch {
        final Job job; final Map<Integer,Long> pending=new HashMap<>(); long dirty,last=System.nanoTime();
        CheckpointBatch(Job j){job=j;}
        synchronized void written(int n,long pos,int bytes,RandomAccessFile out,boolean barrier)throws IOException{
            // A forced checkpoint can lower an offset after an invalid response; never use max here.
            pending.put(n,pos);dirty+=bytes;long now=System.nanoTime();
            long threshold=ExtremePolicy.checkpointBytes(job.speed);
            if(!barrier&&dirty<threshold&&now-last<1_000_000_000L)return;
            out.getFD().sync();job.dataSyncs.incrementAndGet();job.commitBatch(pending);pending.clear();dirty=0;last=now;
        }
    }
    private static final class BufferPool {
        private static final ArrayDeque<byte[]> cache=new ArrayDeque<>();private static int bytes;
        static synchronized byte[] take(int n){for(Iterator<byte[]> it=cache.iterator();it.hasNext();){byte[] b=it.next();if(b.length==n){it.remove();bytes-=n;return b;}}return new byte[n];}
        static synchronized void give(byte[] b){if(bytes+b.length<=4*1024*1024){cache.addLast(b);bytes+=b.length;}}
    }
    public static void copyParts(Job j,OutputStream out,Control control)throws IOException{
        byte[] b=new byte[512*1024];for(int n:j.orderedParts()){control.check();if(j.size(n)==0)continue;try(RandomAccessFile in=new RandomAccessFile(j.storage(n),"r")){in.seek(j.position(n,0));long remain=j.size(n);while(remain>0){control.check();int read=in.read(b,0,(int)Math.min(b.length,remain));if(read<0)throw new EOFException("Missing committed bytes");out.write(b,0,read);remain-=read;}}}
    }
    public static String sha256(Job j,Control c)throws IOException{
        try{MessageDigest md=MessageDigest.getInstance("SHA-256");copyParts(j,new OutputStream(){public void write(int b){md.update((byte)b);}public void write(byte[] b,int o,int n){md.update(b,o,n);}},c);StringBuilder s=new StringBuilder();for(byte b:md.digest())s.append(String.format(Locale.ROOT,"%02x",b&255));return s.toString();}catch(NoSuchAlgorithmException e){throw new IOException(e);}
    }
}
