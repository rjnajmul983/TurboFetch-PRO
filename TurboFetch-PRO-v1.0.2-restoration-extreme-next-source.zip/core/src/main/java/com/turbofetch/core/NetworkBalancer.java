package com.turbofetch.core;
/** Weighted two-route allocation using completed payload observations. No platform dependencies. */
public final class NetworkBalancer {
    private final int[] active=new int[2], samples=new int[2];
    private final long[] bytes=new long[2], blocked=new long[2];
    private final double[] rate=new double[2];private int sequence;
    public synchronized int acquire(long now){int a=choose(now);if(a>=0)active[a]++;return a;}
    private int choose(long now){boolean a=now>=blocked[0],b=now>=blocked[1];if(!a&&!b)return -1;if(!a)return 1;if(!b)return 0;
        if(samples[0]==0||samples[1]==0){if(active[0]!=active[1])return active[0]<active[1]?0:1;return sequence++&1;}
        // Occasionally explore the other path, to relearn after changing conditions.
        if(++sequence%12==0)return rate[0]<rate[1]?0:1;
        double r0=Math.max(1,rate[0])/(active[0]+1),r1=Math.max(1,rate[1])/(active[1]+1);return r0>=r1?0:1;
    }
    public synchronized void success(int route,long useful,long nanos){if(route<0||useful<=0||nanos<=0)return;double v=useful*1e9/nanos;rate[route]=samples[route]==0?v:.7*rate[route]+.3*v;samples[route]=Math.min(1000,samples[route]+1);bytes[route]+=useful;}
    public synchronized void release(int route){if(route>=0&&active[route]>0)active[route]--;}
    public synchronized void fail(int route,long now){if(route>=0){release(route);blocked[route]=now+15_000_000_000L;}}
    public synchronized String report(){return String.format(java.util.Locale.ROOT,"Wi-Fi measured %.2f MiB/s (%d bytes); cellular measured %.2f MiB/s (%d bytes)",rate[0]/1048576,bytes[0],rate[1]/1048576,bytes[1]);}
}
