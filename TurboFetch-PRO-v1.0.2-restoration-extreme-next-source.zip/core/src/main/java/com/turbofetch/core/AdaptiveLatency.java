package com.turbofetch.core;
/** Per-transfer response-time estimator; network changes discard stale measurements. */
public final class AdaptiveLatency {
    private String network=""; private double mean,dev; private int samples,penalty;
    private void refresh(String n){if(!java.util.Objects.equals(network,n)){network=n;mean=dev=0;samples=penalty=0;}}
    public synchronized void observe(String n,long ms){refresh(n);double v=Math.max(1,Math.min(60000,ms));if(samples==0){mean=v;dev=v/2;}else{dev=.75*dev+.25*Math.abs(mean-v);mean=.8*mean+.2*v;}samples=Math.min(1000,samples+1);penalty=Math.max(0,penalty-1);}
    public synchronized void timeout(String n){refresh(n);penalty=Math.min(3,penalty+1);}
    public synchronized int connect(String n){refresh(n);return estimate(ExtremePolicy.connectTimeout(n),5000,30000,4);}
    public synchronized int read(String n){refresh(n);return estimate(ExtremePolicy.readTimeout(n),12000,60000,8);}
    private int estimate(int fallback,int min,int max,int multiplier){if(samples<3)return (int)Math.min(max,(long)fallback*(1+penalty));return (int)Math.max(min,Math.min(max,(mean+4*dev)*multiplier+min+penalty*5000));}
    public synchronized long responseMillis(String n){refresh(n);return samples==0?-1:Math.round(mean);}
}
