package com.turbofetch.core;
import java.io.InterruptedIOException;
/** Cooperative cap for the original scanner; never suppress a candidate or reuse private metadata. */
public final class BrowserProbeGate {
 private static int active,transfers;
 public static synchronized void transferStarted(){transfers++;}
 public static synchronized void transferFinished(){if(transfers>0)transfers--;BrowserProbeGate.class.notifyAll();}
 public static synchronized void enter()throws InterruptedIOException{while(active>=(transfers>0?2:4)){try{BrowserProbeGate.class.wait();}catch(InterruptedException e){Thread.currentThread().interrupt();throw new InterruptedIOException("Scanner interrupted");}}active++;}
 public static synchronized void exit(){if(active>0)active--;BrowserProbeGate.class.notifyAll();}
}
