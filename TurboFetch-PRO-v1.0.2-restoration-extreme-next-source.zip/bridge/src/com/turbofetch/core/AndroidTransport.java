package com.turbofetch.core;
import java.io.IOException;
import java.net.*;
import java.util.*;
import java.util.concurrent.atomic.*;
/** Public Android APIs, isolated from JVM core. No global socket factory or process binding. */
public final class AndroidTransport implements Engine.Transport {
 private final Object context; private final boolean authenticated,dual;
 private final AtomicBoolean platformOnly=new AtomicBoolean();
 private final NetworkBalancer balancer=new NetworkBalancer();
 private final Map<HttpURLConnection,Integer> routes=Collections.synchronizedMap(new WeakHashMap<>());
 private final Map<HttpURLConnection,Boolean> accelerated=Collections.synchronizedMap(new WeakHashMap<>());
 private volatile String status="Platform HTTP";
 private static Object httpEngine; private static boolean engineUnavailable;
 public AndroidTransport(Object context,boolean authenticated){this.context=context;this.authenticated=authenticated;this.dual=allowed(context)&&!authenticated;}
 private static Object call(String cls,Object obj,String name,Class<?>[] types,Object...args)throws Exception{return Class.forName(cls).getMethod(name,types).invoke(obj,args);}
 private static final Class<?>[] NONE={};
 private static Object service(Object ctx)throws Exception{return call("android.content.Context",ctx,"getSystemService",new Class<?>[]{String.class},"connectivity");}
 private static boolean allowed(Object ctx){if(ctx==null)return false;try{
  Class<?> c=Class.forName("android.content.Context");
  if((Boolean)call("com.turbofetch.app.TransferOptions",null,"wifiOnly",new Class<?>[]{c},ctx))return false;
  Object p=call("android.content.Context",ctx,"getSharedPreferences",new Class<?>[]{String.class,int.class},"hyper_transport",0);
  return (Boolean)call("android.content.SharedPreferences",p,"getBoolean",new Class<?>[]{String.class,boolean.class},"dual_consent",false);
 }catch(Exception|LinkageError e){return false;}}
 private static boolean has(Object caps,String name,int x)throws Exception{return (Boolean)call("android.net.NetworkCapabilities",caps,name,new Class<?>[]{int.class},x);}
 private Object[] available() throws Exception{
  Object cm=service(context);Class<?> n=Class.forName("android.net.Network");Object active=call("android.net.ConnectivityManager",cm,"getActiveNetwork",NONE);
  if(active==null)return null;Object ac=call("android.net.ConnectivityManager",cm,"getNetworkCapabilities",new Class<?>[]{n},active);
  if(ac==null||has(ac,"hasTransport",4))return null;
  if(!has(ac,"hasCapability",16)||!has(ac,"hasCapability",12))return null;
  Object wifi=null,cell=null;
  Object[] networks=(Object[])call("android.net.ConnectivityManager",cm,"getAllNetworks",NONE);
  for(Object network:networks){Object caps=call("android.net.ConnectivityManager",cm,"getNetworkCapabilities",new Class<?>[]{n},network);if(caps==null||!has(caps,"hasCapability",16)||!has(caps,"hasCapability",12)||!has(caps,"hasCapability",15)||has(caps,"hasTransport",4))continue;
   if(has(caps,"hasTransport",1))wifi=network;if(has(caps,"hasTransport",0))cell=network;}
  return wifi!=null&&cell!=null?new Object[]{wifi,cell}:null;
 }
 private static synchronized Object engine(Object ctx){
  if(engineUnavailable)return null;if(httpEngine!=null)return httpEngine;
  try{Class<?> c=Class.forName("android.content.Context"),b=Class.forName("android.net.http.HttpEngine$Builder");Object app=call("android.content.Context",ctx,"getApplicationContext",NONE);Object builder=b.getConstructor(c).newInstance(app==null?ctx:app);b.getMethod("setEnableQuic",boolean.class).invoke(builder,true);b.getMethod("setEnableHttp2",boolean.class).invoke(builder,true);httpEngine=b.getMethod("build").invoke(builder);return httpEngine;}
  catch(Exception|LinkageError e){engineUnavailable=true;return null;}
 }
 public HttpURLConnection open(URL target,boolean verifiedRange)throws IOException{
  if(context!=null&&!platformOnly.get()&&dual&&verifiedRange&&allowed(context)&&target.getProtocol().equals("https"))try{
   Object[] pair=available();if(pair!=null){int i=balancer.acquire(System.nanoTime());if(i>=0){try{HttpURLConnection c=(HttpURLConnection)call("android.net.Network",pair[i],"openConnection",new Class<?>[]{URL.class},target);routes.put(c,i);status="Dual-network weighted routing (experimental)";return c;}catch(Exception|LinkageError ex){balancer.fail(i,System.nanoTime());}}}
  }catch(Exception|LinkageError e){platformOnly.set(true);status="Platform fallback";}
  if(context!=null&&!platformOnly.get()&&!authenticated&&target.getProtocol().equals("https"))try{
   Object e=engine(context);if(e!=null){HttpURLConnection c=(HttpURLConnection)call("android.net.http.HttpEngine",e,"openConnection",new Class<?>[]{URL.class},target);accelerated.put(c,true);status="Android HttpEngine (HTTP/2 + QUIC enabled; negotiated protocol unknown)";return c;}
  }catch(Exception|LinkageError e){platformOnly.set(true);status="Platform fallback";}
  if(!platformOnly.get())status="Platform HTTP (no accelerated route selected)";
  if(context==null)status="Platform HTTP";
  return (HttpURLConnection)target.openConnection();
 }
 public void failed(HttpURLConnection c,IOException e){Integer i=routes.remove(c);if(i!=null){balancer.fail(i,System.nanoTime());return;}if(Boolean.TRUE.equals(accelerated.remove(c))){platformOnly.set(true);status="Platform fallback after transport error";}}
 public void transferred(HttpURLConnection c,long bytes,long nanos){Integer i=routes.get(c);if(i!=null)balancer.success(i,bytes,nanos);}
 public void closed(HttpURLConnection c){Integer i=routes.remove(c);if(i!=null)balancer.release(i);accelerated.remove(c);}
 public String description(){return dual?status+"\n"+balancer.report():status;}
}
