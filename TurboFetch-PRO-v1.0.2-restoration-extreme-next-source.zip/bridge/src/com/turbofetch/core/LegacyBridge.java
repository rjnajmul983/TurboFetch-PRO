package com.turbofetch.core;
import com.turbofetch.app.engine.DownloadJob;
import com.turbofetch.app.engine.TurboEngine;
import java.io.*;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.file.*;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.*;

/** Adapter called by original TurboEngine.download. Non-HTTP engines are never redirected here. */
public final class LegacyBridge {
 private static String str(String s){return s==null?"":s;}
 private static File dir(File root,DownloadJob old)throws IOException{
  if(!str(old.id).matches("[a-zA-Z0-9_-]{1,120}"))throw new IOException("Invalid job ID");
  return new File(root,old.id+"-stream"); // original deletePartial already removes this suffix
 }
 public static void guardStreamManifestChange(File dir)throws IOException{File[] files=dir.listFiles();if(files==null)throw new IOException("Cannot inspect existing stream cache");for(File f:files){String name=f.getName();if(!name.equals("stream-signature")&&f.isFile()&&f.length()>0)throw new IOException("Stream manifest changed; existing segments retained. Review or explicitly cancel before restarting.");}}
 public static boolean preserveFtpPartial(File file)throws IOException{if(file.isFile()&&file.length()>0)throw new IOException("FTP resume rejected or remote file changed; existing partial data retained");return file.delete();}
 public static boolean mayClear(DownloadJob old){
  if(old==null||old.workerOwned||old.serviceOwned)return false;
  return "COMPLETED".equals(old.status)||"CANCELLED".equals(old.status)||("FAILED".equals(old.status)&&old.downloadedBytes==0&&str(old.outputUri).isEmpty());
 }
 public static void protectLegacy(DownloadJob old,File root)throws IOException{
  if(old.downloadedBytes>0||new File(root,old.id+".part").length()>0)throw new IOException("Saved partial retained: remote file changed or server rejected resume. Cancel/re-add only after review.");
  protectParts(old);
 }
 public static void protectParts(DownloadJob old)throws IOException{
  if(old.downloadedBytes>0)throw new IOException("Saved range metadata retained; cannot rebuild existing ranges safely");
  synchronized(old.parts){for(DownloadJob.Part p:old.parts)if(p.done>0)throw new IOException("Saved range metadata retained");}
 }
 /** Original ranged() may silently reset progress when the file is missing or has changed length. */
 private static void checkLegacy(DownloadJob old,File partial)throws IOException{
  if(old.downloadedBytes<=0 && old.parts.isEmpty())return;
  if(!partial.isFile()||old.totalBytes<=0||partial.length()!=old.totalBytes||old.parts.isEmpty())throw new IOException("Legacy partial cannot be safely resumed; data retained");
  long next=0,done=0;
  synchronized(old.parts){for(DownloadJob.Part p:old.parts){if(p.start!=next||p.end<p.start||p.end>=old.totalBytes||p.done<0||p.done>p.end-p.start+1)throw new IOException("Invalid legacy range metadata; data retained");next=p.end+1;done+=p.done;}}
  if(next!=old.totalBytes||done!=old.downloadedBytes)throw new IOException("Legacy range checkpoint mismatch; data retained");
 }
 private static void sync(Job j,DownloadJob old){
  old.downloadedBytes=j.bytes.get();old.totalBytes=j.total;old.speedBps=j.speed;old.etag=j.etag;old.lastModified=j.modified;old.totalSegments=j.partCount;
 }
 private static String filename(String header){
  try{Matcher m=Pattern.compile("(?i)(?:^|;)\\s*filename\\*=UTF-8''([^;]+)").matcher(header);if(m.find())return URLDecoder.decode(m.group(1).trim().replace("+","%2B"),"UTF-8");
  m=Pattern.compile("(?i)(?:^|;)\\s*filename\\s*=\\s*(?:\"([^\"]*)\"|([^;]+))").matcher(header);if(m.find())return m.group(1)!=null?m.group(1):m.group(2).trim();}catch(Exception ignored){}return "";
 }
 private static boolean samePath(String a,String b){try{URI x=new URI(a),y=new URI(b);return x.getScheme().equalsIgnoreCase(y.getScheme())&&x.getHost().equalsIgnoreCase(y.getHost())&&x.getPort()==y.getPort()&&java.util.Objects.equals(x.getPath(),y.getPath());}catch(Exception e){return false;}}
 /** null means use the original engine; it is never returned after new data has been written. */
 public static File download(DownloadJob old,File root,TurboEngine.Listener listener,TurboEngine.SpaceCheck space,AtomicBoolean stopped)throws IOException{
  File home=dir(root,old), legacy=new File(root,old.id+".part"), meta=new File(home,"job.properties");
  if(!meta.exists()&&(legacy.exists()||old.downloadedBytes>0||!old.parts.isEmpty())){checkLegacy(old,legacy);return null;}
  Store.validate(old.url);
  if(stopped.get())throw new InterruptedIOException("Paused");
  if(!home.isDirectory()&&!home.mkdirs())throw new IOException("Cannot create persistent range directory");
  Job j;
  if(meta.exists()){
   j=Job.load(home);
   if(!j.url.equals(old.url)){
    if(!samePath(j.url,old.url)&&j.sha256.isEmpty())throw new IOException("Replacement URL needs a trusted SHA-256; data retained");
    j.url=old.url;j.save();
   }
  }else{
   String[] existing=home.list();if(existing==null||existing.length!=0)throw new IOException("Unknown partial metadata; data retained");
   j=new Job(home,old.id,old.url,Store.clean(str(old.fileName)));j.sha256=str(old.expectedSha256).toLowerCase(Locale.ROOT);
   if(!j.sha256.isEmpty()&&!j.sha256.matches("[0-9a-f]{64}"))throw new IOException("Invalid SHA-256");j.save();
  }
  // The original service may have updated settings; preserve explicit manual cap and speed limit.
  j.connections=Math.max(1,Math.min(32,old.connections));j.userAgent=str(old.userAgent);j.save();
  if(j.state==Job.State.COMPLETED){File ready=new File(j.output);if(!ready.getCanonicalFile().getParentFile().equals(home.getCanonicalFile())||!ready.isFile()||ready.length()!=j.total)throw new IOException("Completed temporary file missing; no automatic restart");space.check(j.total);sync(j,old);return ready;}
  Engine.Control c=new Engine.Control();c.directStorage=true;c.dynamicRanges=true;c.retainPartsAfterPublish=true;c.fixedWorkers=!old.adaptive;c.cookie=str(old.cookieHeader);c.referer=str(old.referer);c.speedLimitKiB=Math.max(0,old.speedLimitKiB);
  Object context=RuntimeSignals.context();c.pipelineMode=RuntimeSignals.pipelineRequested(context)?1:0;c.transport=new AndroidTransport(context,!c.cookie.isEmpty()||!c.referer.isEmpty());PerformancePolicy policy=new PerformancePolicy();
  RuntimeSignals.Sample initial=RuntimeSignals.sample(context);c.network=initial.network;c.workerBudget=c.speedLimitKiB>0?1:policy.update(initial.heat,initial.saver,initial.low);
  c.metadata=(size,mime,disposition)->{if(size>=0)space.check(size);if(!mime.isEmpty())old.mimeType=mime.split(";",2)[0].trim();if(!old.userNamedFile){String n=filename(disposition);if(!n.isEmpty()){old.fileName=Store.clean(n);j.name=old.fileName;}}};
  AtomicBoolean finished=new AtomicBoolean(false);
  Thread monitor=new Thread(()->{long nextSample=0,lastReport=0,lastBytes=-1;Job.State lastState=null;while(!finished.get()){if(System.nanoTime()>=nextSample){RuntimeSignals.Sample sample=RuntimeSignals.sample(context);c.network=sample.network;c.workerBudget=c.speedLimitKiB>0?1:policy.update(sample.heat,sample.saver,sample.low);RuntimeSignals.update(j,c,sample);nextSample=System.nanoTime()+1_000_000_000L;}if(stopped.get()){c.pause();return;}long now=System.nanoTime();long bytes=j.bytes.get();Job.State state=j.state;if(state!=lastState||((bytes!=lastBytes||j.speed!=old.speedBps)&&now-lastReport>=500_000_000L)||now-lastReport>=2_000_000_000L){sync(j,old);try{listener.onUpdate(old);}catch(RuntimeException ignored){}lastBytes=bytes;lastState=state;lastReport=now;}try{Thread.sleep(250);}catch(InterruptedException e){return;}}},"hyper-legacy-progress");monitor.setDaemon(true);monitor.start();
  BrowserProbeGate.transferStarted();
  try{
   new Engine().run(j,c,(job,control)->{
    control.check();space.check(job.total);
    File ready;if(job.direct)ready=job.directFile();else if(job.partCount==1)ready=job.data(0);else{
     if(home.getUsableSpace()<job.total)throw new IOException("Insufficient space for segment assembly");
     ready=new File(home,"ready.bin");File tmp=new File(home,"ready.tmp");try(FileOutputStream out=new FileOutputStream(tmp)){Engine.copyParts(job,out,control);out.getFD().sync();}Job.move(tmp,ready);
    }
    if(!ready.isFile()||ready.length()!=job.total)throw new IOException("Temporary output size mismatch");return ready.getAbsolutePath();
   });
  }finally{BrowserProbeGate.transferFinished();finished.set(true);monitor.interrupt();try{monitor.join();}catch(InterruptedException e){Thread.currentThread().interrupt();}sync(j,old);RuntimeSignals.finish(j,c,RuntimeSignals.sample(context));listener.onUpdate(old);}
  if(stopped.get()||j.state==Job.State.PAUSED||j.state==Job.State.WAITING_NETWORK)throw new InterruptedIOException("Paused; committed bytes saved");
  if(j.state!=Job.State.COMPLETED)throw new IOException(j.error.isEmpty()?"Download failed; saved bytes retained":j.error);
  return new File(j.output);
 }
 public static void cleanup(File root,DownloadJob old){
  if(!"HTTP".equals(old.kind)||!"COMPLETED".equals(old.status))return;
  try{File home=dir(root,old);if(!new File(home,"job.properties").isFile())return;File[] files=home.listFiles();if(files==null)return;for(File f:files)if(f.isFile())Files.deleteIfExists(f.toPath());Files.deleteIfExists(home.toPath());}catch(IOException ignored){}
 }
}
