package com.turbofetch.app.engine;
import java.io.IOException;
/** Compile-time ABI mirror only. */
public class TurboEngine {
 public interface Listener {void onUpdate(DownloadJob job);}
 public interface SpaceCheck {void check(long bytes) throws IOException;}
}
